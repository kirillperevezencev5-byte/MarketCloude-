#!/usr/bin/env python3
"""MarketPilot entry point:  python3 run.py   (Python 3.10+, no dependencies)."""
import logging
import signal
import sys
import threading

if sys.version_info < (3, 10):
    sys.exit("MarketPilot requires Python 3.10 or newer")

from marketpilot import api, bot, db, scheduler, server, telegram  # noqa: F401  (api registers routes)
from marketpilot.config import cfg


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    db.init()
    stop = threading.Event()

    threads = [threading.Thread(target=scheduler.run_forever, args=(stop,), name="scheduler", daemon=True)]
    if cfg.BOT_TOKEN:
        threads.append(threading.Thread(target=bot.poll_forever, args=(stop,), name="bot", daemon=True))
    for t in threads:
        t.start()

    srv = server.make_server()
    url = f"http://{cfg.HOST}:{cfg.PORT}"
    print("=" * 62)
    print(f" MarketPilot {cfg.VERSION} запущен: {url}")
    if cfg.BOT_TOKEN:
        print(" Telegram: подключаюсь к боту (статус виден в приложении)")
    else:
        print(" Telegram: BOT_TOKEN не задан -> работает ДЕМО-РЕЖИМ")
    print(" Остановить: Ctrl+C")
    print("=" * 62)

    def shutdown(*_):
        stop.set()
        threading.Thread(target=srv.shutdown, daemon=True).start()

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)
    try:
        srv.serve_forever()
    finally:
        stop.set()
        srv.server_close()


if __name__ == "__main__":
    main()
