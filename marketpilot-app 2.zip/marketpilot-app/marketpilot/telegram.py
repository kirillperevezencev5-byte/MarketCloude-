"""Telegram Bot API client (stdlib only) + rights evaluation.

Network errors are split in two: failures before the request reached Telegram (safe to retry) and
failures after it was sent (ambiguous: the message may be delivered -> do NOT auto-retry).
"""
import json
import socket
import threading
import time
import urllib.error
import urllib.request

from .config import cfg


class TelegramError(Exception):
    def __init__(self, code: int, description: str, retry_after: int | None = None):
        super().__init__(f"{code}: {description}")
        self.code, self.description, self.retry_after = code, description, retry_after

    @property
    def permanent(self) -> bool:
        return self.code in (400, 401, 403, 404)


class TelegramNetworkError(Exception):
    def __init__(self, message: str, ambiguous: bool):
        super().__init__(message)
        self.ambiguous = ambiguous


class RateLimiter:
    """Global rps + minimum interval per chat (single process)."""

    def __init__(self, rps: int, chat_interval: float):
        self.rps, self.chat_interval = rps, chat_interval
        self._start = time.monotonic()
        self._count = 0
        self._last: dict[int, float] = {}
        self._lock = threading.Lock()

    def acquire(self, chat_id: int) -> None:
        while True:
            with self._lock:
                now = time.monotonic()
                if now - self._start >= 1.0:
                    self._start, self._count = now, 0
                chat_wait = self._last.get(chat_id, 0) + self.chat_interval - now
                if self._count < self.rps and chat_wait <= 0:
                    self._count += 1
                    self._last[chat_id] = now
                    return
                wait = max(chat_wait, self._start + 1.0 - now, 0.01)
            time.sleep(wait)


class TelegramClient:
    def __init__(self, token: str, base: str):
        self.token, self.base = token, base
        self.limiter = RateLimiter(cfg.TG_GLOBAL_RPS, cfg.TG_CHAT_INTERVAL)

    def call(self, method: str, chat_id: int | None = None, http_timeout: float = 30, **params):
        if chat_id is not None:
            self.limiter.acquire(chat_id)
            params["chat_id"] = chat_id
        req = urllib.request.Request(
            f"{self.base}/bot{self.token}/{method}",
            data=json.dumps(params).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=http_timeout) as resp:
                data = json.loads(resp.read())
        except urllib.error.HTTPError as e:  # Telegram returns JSON bodies on 4xx
            try:
                data = json.loads(e.read())
            except Exception:
                raise TelegramError(e.code, str(e))
        except urllib.error.URLError as e:
            reason = e.reason
            before_send = isinstance(reason, (ConnectionRefusedError, socket.gaierror))
            raise TelegramNetworkError(f"{type(reason).__name__}: {reason}", ambiguous=not before_send)
        except (TimeoutError, socket.timeout, ConnectionError, OSError) as e:
            raise TelegramNetworkError(f"{type(e).__name__}: {e}", ambiguous=True)
        if not data.get("ok"):
            retry_after = (data.get("parameters") or {}).get("retry_after")
            raise TelegramError(data.get("error_code", 0), data.get("description", ""), retry_after)
        return data["result"]

    # helpers
    def get_me(self):
        return self.call("getMe", http_timeout=15)

    def send_message(self, chat_id, text, parse_mode="HTML", reply_markup=None):
        params = {"text": text}
        if parse_mode:
            params["parse_mode"] = parse_mode
        if reply_markup:
            params["reply_markup"] = reply_markup
        return self.call("sendMessage", chat_id, **params)

    def send_photo(self, chat_id, photo_url, caption="", parse_mode="HTML"):
        params = {"photo": photo_url}
        if caption:
            params["caption"] = caption
            if parse_mode:
                params["parse_mode"] = parse_mode
        return self.call("sendPhoto", chat_id, **params)

    def member_count(self, chat_id) -> int:
        return self.call("getChatMemberCount", chat_id, http_timeout=15)

    def chat_member(self, chat_id, user_id) -> dict:
        return self.call("getChatMember", chat_id, http_timeout=15, user_id=user_id)


_client: TelegramClient | None = None


def client() -> TelegramClient | None:
    global _client
    if _client is None and cfg.BOT_TOKEN:
        _client = TelegramClient(cfg.BOT_TOKEN, cfg.TG_API_BASE)
    return _client


# live connection state shown in the UI (updated by bot.py)
state = {"connected": False, "username": "", "bot_id": None, "error": None}


def is_live() -> bool:
    return bool(state["connected"])


# ---------- rights ----------
FEATURE_RIGHTS = {
    "channel": {"publish": ["can_post_messages"], "edit_messages": ["can_edit_messages"],
                "delete_messages": ["can_delete_messages"]},
    "group": {"publish": [], "delete_messages": ["can_delete_messages"],
              "restrict_members": ["can_restrict_members"], "pin_messages": ["can_pin_messages"]},
}
FEATURE_RIGHTS["supergroup"] = FEATURE_RIGHTS["group"]


def evaluate_rights(resource_type: str, member: dict) -> tuple[list[str], list[str]]:
    """(capabilities, missing_rights) from the bot's own getChatMember result."""
    if member.get("status") != "administrator":
        return [], ["administrator"]
    caps, missing = [], set()
    for feature, needed in FEATURE_RIGHTS[resource_type].items():
        lacking = [r for r in needed if not member.get(r)]
        if lacking:
            missing.update(lacking)
        else:
            caps.append(feature)
    return caps, sorted(missing)
