"""Telegram bot: long polling (no public HTTPS needed for local use) and update handlers."""
import json
import logging
import threading
import time

from . import db, security, telegram
from .config import cfg
from .telegram import TelegramError, TelegramNetworkError

log = logging.getLogger("marketpilot.bot")

ALLOWED_UPDATES = ["message", "channel_post", "my_chat_member", "chat_member"]
CHAT_TYPES = {"channel": "channel", "group": "group", "supergroup": "supergroup"}


# ---------- helpers ----------
def miniapp_url(page: str | None = None) -> str | None:
    """Telegram only opens Mini Apps over HTTPS (no localhost / plain http)."""
    base = cfg.PUBLIC_URL
    if not base.startswith("https://"):
        return None
    return base + "/app/" + (f"?p={page}" if page else "")


def webapp_markup(page: str | None = None, text: str = "🚀 Открыть приложение"):
    """Inline keyboard with a web_app button: opens the Mini App inside Telegram (no external browser)."""
    url = miniapp_url(page)
    if not url:
        return None
    return {"inline_keyboard": [[{"text": text, "web_app": {"url": url}}]]}


def say(chat_id, text, parse_mode=None, reply_markup=None):
    c = telegram.client()
    if not c:
        return
    try:
        c.send_message(chat_id, text, parse_mode=parse_mode, reply_markup=reply_markup)
    except (TelegramError, TelegramNetworkError) as e:
        log.warning("send to %s failed: %s", chat_id, e)


def notify_owner(user_id: int, text: str, page: str = "notifications") -> None:
    """Send a Telegram notification to the owner of a workspace (skipped for demo users / notifications off).
    When the Mini App is configured the message carries a button that opens the relevant section."""
    user = db.one("SELECT * FROM users WHERE id=?", user_id)
    if user and not user["is_demo"] and user["notify"] and telegram.is_live():
        say(user["telegram_id"], text, reply_markup=webapp_markup(page, "🚀 Открыть"))


def _today() -> str:
    return db.now().strftime("%Y-%m-%d")


def _bump(resource_id: int, field: str) -> None:
    db.run(
        f"INSERT INTO group_stats(resource_id, day, {field}) VALUES(?,?,1) "
        f"ON CONFLICT(resource_id, day) DO UPDATE SET {field} = {field} + 1",
        resource_id, _today(),
    )


# ---------- handlers ----------
def handle_update(upd: dict) -> None:
    if "message" in upd:
        handle_message(upd["message"])
    elif "channel_post" in upd:
        handle_channel_post(upd["channel_post"])
    elif "my_chat_member" in upd:
        handle_my_chat_member(upd["my_chat_member"])
    elif "chat_member" in upd:
        handle_chat_member(upd["chat_member"])


def handle_message(msg: dict) -> None:
    chat, text = msg["chat"], (msg.get("text") or "").strip()
    if chat["type"] == "private":
        if text.startswith("/start login_"):
            return confirm_login(msg, text[len("/start login_"):].strip())
        if text.startswith(("/start", "/help", "/app")):
            return send_welcome(chat["id"])
        return
    if chat["type"] in ("group", "supergroup"):
        if text.startswith("/connect"):
            parts = text.split()
            if len(parts) >= 2:
                link_resource(chat, parts[1].split("@")[0], msg.get("from") or {})
            return
        # privacy: only counters are stored, never message content
        res = db.q("SELECT id FROM resources WHERE chat_id=? AND status!='disconnected'", chat["id"])
        for r in res:
            _bump(r["id"], "messages")


def send_welcome(chat_id: int) -> None:
    web = cfg.PUBLIC_URL or f"http://{cfg.HOST}:{cfg.PORT}"
    text = ("Привет! Я MarketPilot — помогаю управлять Telegram-каналами и группами: публикации по расписанию, "
            "аналитика и уведомления в одном приложении.\n\n")
    markup = webapp_markup()
    if markup:
        text += "Нажмите кнопку ниже, чтобы открыть приложение прямо в Telegram."
    else:
        text += (f"Веб-панель: {web}\n\nМини-приложение в Telegram пока не настроено: для него нужен HTTPS-адрес "
                 "(переменная PUBLIC_URL). См. docs/MINIAPP.md.")
    text += ("\n\nЧтобы подключить канал или группу: откройте «Работа» → «Ресурсы» → «Подключить», добавьте меня "
             "администратором и отправьте в чате команду /connect КОД.")
    say(chat_id, text, reply_markup=markup)


def configure_bot() -> None:
    """Commands and the chat menu button ("🚀 Открыть") that launches the Mini App for every user."""
    c = telegram.client()
    try:
        c.call("setMyCommands", commands=[
            {"command": "start", "description": "Запустить бота и открыть приложение"},
            {"command": "app", "description": "🚀 Открыть приложение"},
            {"command": "help", "description": "Помощь"},
        ])
    except (TelegramError, TelegramNetworkError) as e:
        log.warning("setMyCommands failed: %s", e)
    url = miniapp_url()
    if not url:
        log.warning("PUBLIC_URL is not an https:// address -> Mini App buttons are disabled (see docs/MINIAPP.md)")
        return
    try:
        c.call("setChatMenuButton", menu_button={"type": "web_app", "text": "🚀 Открыть", "web_app": {"url": url}})
        log.info("Mini App menu button set: %s", url)
    except (TelegramError, TelegramNetworkError) as e:
        log.warning("setChatMenuButton failed: %s", e)


def handle_channel_post(post: dict) -> None:
    text = (post.get("text") or "").strip()
    if text.startswith("/connect"):
        parts = text.split()
        if len(parts) >= 2:
            link_resource(post["chat"], parts[1], {})


def confirm_login(msg: dict, raw_token: str) -> None:
    row = db.one("SELECT * FROM login_tokens WHERE token_hash=?", security.hash_token(raw_token))
    chat_id = msg["chat"]["id"]
    if row is None or row["consumed"] or row["expires_at"] < db.now_iso():
        return say(chat_id, "Ссылка для входа устарела. Обновите страницу входа и попробуйте снова.")
    user = security.upsert_telegram_user(msg["from"])
    db.run("UPDATE login_tokens SET user_id=?, confirmed=1 WHERE token_hash=?", user["id"], row["token_hash"])
    say(chat_id, "✅ Вход подтверждён. Вернитесь в браузер.")


def link_resource(chat: dict, code: str, sender: dict) -> None:
    c = telegram.client()
    link = db.one("SELECT * FROM link_codes WHERE code=?", code.upper())
    if link is None or link["used"] or link["expires_at"] < db.now_iso():
        return say(chat["id"], "Код недействителен или истёк. Создайте новый в панели MarketPilot.")
    rtype = CHAT_TYPES.get(chat["type"])
    if rtype is None:
        return
    try:
        if sender.get("id"):  # in groups only an admin may link the chat
            who = c.chat_member(chat["id"], sender["id"])
            if who.get("status") not in ("creator", "administrator"):
                return say(chat["id"], "Подключить чат может только администратор.")
        me = telegram.state["bot_id"]
        member = c.chat_member(chat["id"], me)
        count = c.member_count(chat["id"])
    except (TelegramError, TelegramNetworkError) as e:
        return say(chat["id"], f"Не удалось проверить права бота: {e}")

    caps, missing = telegram.evaluate_rights(rtype, member)
    status = "active" if "publish" in caps else "missing_rights"
    user_id = link["user_id"]
    user = db.one("SELECT * FROM users WHERE id=?", user_id)
    from .config import PLANS
    limit = PLANS.get(user["plan"], PLANS["free"])["resources"]
    existing = db.one("SELECT * FROM resources WHERE user_id=? AND chat_id=?", user_id, chat["id"])
    used = db.one("SELECT COUNT(*) n FROM resources WHERE user_id=? AND status!='disconnected' AND is_demo=0", user_id)["n"]
    if (existing is None or existing["status"] == "disconnected") and used >= limit:
        return say(chat["id"], f"Достигнут лимит тарифа: {limit} ресурсов.")

    with db.tx():
        if existing:
            db.run("UPDATE resources SET title=?, username=?, type=?, status=?, capabilities=?, missing_rights=?, "
                   "members=?, last_checked_at=?, is_demo=0 WHERE id=?",
                   chat.get("title", ""), chat.get("username"), rtype, status, json.dumps(caps), json.dumps(missing),
                   count, db.now_iso(), existing["id"])
            rid = existing["id"]
        else:
            rid = db.insert("resources", user_id=user_id, chat_id=chat["id"], title=chat.get("title", ""),
                            username=chat.get("username"), type=rtype, status=status,
                            capabilities=json.dumps(caps), missing_rights=json.dumps(missing), members=count,
                            connected_at=db.now_iso(), last_checked_at=db.now_iso())
        db.insert("snapshots", resource_id=rid, members=count, taken_at=db.now_iso())
        db.run("UPDATE link_codes SET used=1 WHERE code=?", link["code"])
        db.event(user_id, "resource_connected", f"Подключён ресурс «{chat.get('title', '')}»", rid)
    if status == "active":
        say(chat["id"], "✅ Ресурс подключён к MarketPilot.")
    else:
        say(chat["id"], "Ресурс подключён, но боту не хватает прав: " + ", ".join(missing))


def handle_my_chat_member(upd: dict) -> None:
    """Rights of the bot changed or the bot was removed."""
    chat = upd["chat"]
    new = upd["new_chat_member"]
    rtype = CHAT_TYPES.get(chat["type"])
    if rtype is None:
        return
    for res in db.q("SELECT * FROM resources WHERE chat_id=? AND status!='disconnected'", chat["id"]):
        if new["status"] in ("left", "kicked"):
            caps, missing, status = [], ["administrator"], "disconnected"
            msg = f"Бот удалён из «{res['title']}», ресурс отключён"
        else:
            caps, missing = telegram.evaluate_rights(rtype, new)
            status = "active" if "publish" in caps else "missing_rights"
            msg = (f"Права бота в «{res['title']}» изменены" +
                   (f": не хватает {', '.join(missing)}" if missing else ""))
        db.run("UPDATE resources SET status=?, capabilities=?, missing_rights=?, last_checked_at=? WHERE id=?",
               status, json.dumps(caps), json.dumps(missing), db.now_iso(), res["id"])
        db.event(res["user_id"], "rights_changed", msg, res["id"])
        if status == "disconnected":
            cancel_pending(res["id"], "bot removed from chat")
        if status != "active":
            notify_owner(res["user_id"], "⚠️ " + msg)


def handle_chat_member(upd: dict) -> None:
    old, new = upd["old_chat_member"]["status"], upd["new_chat_member"]["status"]
    present = ("member", "administrator", "creator", "restricted")
    joined = old not in present and new in present
    left = old in present and new not in present
    if not (joined or left):
        return
    for r in db.q("SELECT id FROM resources WHERE chat_id=? AND status!='disconnected'", upd["chat"]["id"]):
        _bump(r["id"], "joins" if joined else "leaves")


def cancel_pending(resource_id: int, reason: str) -> None:
    db.run("UPDATE post_targets SET status='cancelled', error=? WHERE resource_id=? AND status IN ('scheduled','draft')",
           reason, resource_id)


# ---------- polling loop ----------
def poll_forever(stop: threading.Event) -> None:
    c = telegram.client()
    if not c:
        return
    # 1. connect (retry until it works; the app stays usable in demo mode meanwhile)
    while not stop.is_set():
        try:
            me = c.get_me()
            telegram.state.update(connected=True, username=me.get("username", ""), bot_id=me["id"], error=None)
            if not cfg.BOT_USERNAME:
                cfg.BOT_USERNAME = me.get("username", "")
            try:
                c.call("deleteWebhook", http_timeout=15)  # polling and webhook are mutually exclusive
            except (TelegramError, TelegramNetworkError):
                pass
            log.info("Telegram connected as @%s", telegram.state["username"])
            configure_bot()
            break
        except TelegramError as e:
            telegram.state.update(connected=False, error=f"Telegram: {e.description or e.code}")
            log.error("Telegram rejected the bot token: %s", e)
        except TelegramNetworkError as e:
            telegram.state.update(connected=False, error=f"Нет связи с Telegram: {e}")
            log.warning("cannot reach Telegram: %s", e)
        stop.wait(30)

    # 2. updates
    offset = int(db.get_meta("tg_offset", "0"))
    while not stop.is_set():
        try:
            updates = _get_updates(c, offset)
            for upd in updates:
                offset = upd["update_id"] + 1
                try:
                    handle_update(upd)
                except Exception:
                    log.exception("update %s failed", upd.get("update_id"))
                db.set_meta("tg_offset", offset)
            telegram.state.update(connected=True, error=None)
        except TelegramError as e:
            telegram.state["error"] = f"Telegram: {e.description or e.code}"
            log.error("getUpdates: %s", e)
            stop.wait(10 if e.code != 429 else (e.retry_after or 5))
        except TelegramNetworkError as e:
            telegram.state.update(connected=False, error=f"Нет связи с Telegram: {e}")
            stop.wait(5)


def _get_updates(c, offset):
    # long polling: server holds the request up to 25 s, socket timeout must be larger
    req_params = {"offset": offset, "limit": 50, "timeout": 25, "allowed_updates": ALLOWED_UPDATES}
    return c.call("getUpdates", http_timeout=40, **req_params)
