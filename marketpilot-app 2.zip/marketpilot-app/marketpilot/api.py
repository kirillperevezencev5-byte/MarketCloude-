"""REST API. Every authenticated query is scoped by the session user's id (tenant isolation)."""
import json
import re
import secrets
from datetime import datetime, timedelta, timezone
from html.parser import HTMLParser
from urllib.parse import urlparse
from zoneinfo import ZoneInfo

from . import bot, db, security, seed, telegram
from .config import PLANS, cfg
from .server import ApiError, route

NOT_FOUND = ApiError(404, "not_found", "Не найдено")


# ====================================================================== helpers
def user_tz(user) -> ZoneInfo:
    try:
        return ZoneInfo(user["timezone"])
    except Exception:
        return ZoneInfo("UTC")


def need(req, field: str, kind=str, default=None, required=True):
    value = req.body.get(field, default)
    if value is None or value == "":
        if required:
            raise ApiError(422, "validation", f"Поле «{field}» обязательно")
        return default
    if kind is not None and not isinstance(value, kind):
        raise ApiError(422, "validation", f"Поле «{field}» имеет неверный тип")
    return value


def parse_when(value: str) -> datetime:
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        raise ApiError(422, "validation", "Неверный формат даты")
    if dt.tzinfo is None:
        raise ApiError(422, "validation", "Дата должна содержать часовой пояс")
    return dt.astimezone(timezone.utc)


ALLOWED_TAGS = {"b", "strong", "i", "em", "u", "ins", "s", "strike", "del", "a", "code", "pre", "tg-spoiler",
                "blockquote", "span"}


class _HtmlCheck(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack, self.visible, self.error = [], 0, None

    def handle_starttag(self, tag, attrs):
        if tag not in ALLOWED_TAGS:
            self.error = self.error or f"Тег <{tag}> не поддерживается Telegram"
            return
        if tag == "a" and not dict(attrs).get("href"):
            self.error = self.error or "У ссылки <a> нужен атрибут href"
        self.stack.append(tag)

    def handle_endtag(self, tag):
        if tag not in ALLOWED_TAGS:
            return
        if not self.stack or self.stack[-1] != tag:
            self.error = self.error or f"Тег </{tag}> закрыт неправильно"
        else:
            self.stack.pop()

    def handle_data(self, data):
        self.visible += len(data)


def validate_text(text: str, has_image: bool) -> None:
    chk = _HtmlCheck()
    chk.feed(text)
    chk.close()
    if chk.error:
        raise ApiError(422, "bad_format", chk.error)
    if chk.stack:
        raise ApiError(422, "bad_format", f"Не закрыт тег <{chk.stack[-1]}>")
    limit = cfg.MAX_CAPTION if has_image else cfg.MAX_TEXT
    if chk.visible > limit:
        raise ApiError(422, "too_long", f"Текст длиннее {limit} символов ({chk.visible})" +
                       (" — подпись к фото ограничена" if has_image else ""))


def validate_image(url) -> str | None:
    if not url:
        return None
    if not isinstance(url, str):
        raise ApiError(422, "validation", "Неверный адрес изображения")
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.netloc or len(url) > 2000:
        raise ApiError(422, "validation", "Адрес изображения должен начинаться с http:// или https://")
    return url


def resource_row(user_id: int, rid: int):
    row = db.one("SELECT * FROM resources WHERE id=? AND user_id=?", rid, user_id)
    if row is None:
        raise NOT_FOUND
    return row


def res_dict(r) -> dict:
    return {
        "id": r["id"], "title": r["title"], "username": r["username"], "type": r["type"], "status": r["status"],
        "capabilities": db.jl(r["capabilities"]), "missing_rights": db.jl(r["missing_rights"]),
        "members": r["members"], "is_demo": bool(r["is_demo"]), "connected_at": r["connected_at"],
        "last_checked_at": r["last_checked_at"],
    }


def target_dict(t) -> dict:
    return {
        "id": t["id"], "post_id": t["post_id"], "resource_id": t["resource_id"],
        "resource_title": t["resource_title"] if "resource_title" in t.keys() else None,
        "status": t["status"], "scheduled_at": t["scheduled_at"], "published_at": t["published_at"],
        "error": t["error"], "message_id": t["message_id"], "attempts": t["attempts"],
    }


def plan_info(user) -> dict:
    limit = PLANS.get(user["plan"], PLANS["free"])["resources"]
    used = db.one("SELECT COUNT(*) n FROM resources WHERE user_id=? AND status!='disconnected' AND is_demo=0",
                  user["id"])["n"]
    return {"plan": user["plan"], "resource_limit": limit, "resources_used": used}


def user_dict(user) -> dict:
    uid = user["id"]
    return {
        "telegram_id": None if user["is_demo"] else user["telegram_id"],
        "posts_total": db.one("SELECT COUNT(*) n FROM posts WHERE user_id=?", uid)["n"],
        "published_total": db.one("SELECT COUNT(*) n FROM post_targets WHERE user_id=? AND status='published'", uid)["n"],
        "id": user["id"], "first_name": user["first_name"], "username": user["username"],
        "language": user["language"], "timezone": user["timezone"], "notify": bool(user["notify"]),
        "is_demo": bool(user["is_demo"]), "created_at": user["created_at"], **plan_info(user),
    }


def start_session(req, user, with_token: bool = False) -> dict:
    raw = security.create_session(user["id"])
    req.set_session(raw)
    out = {"user": user_dict(user)}
    if with_token:  # Mini App: some Telegram webviews restrict cookies, so it sends a Bearer token instead
        out["token"] = raw
    return out


def limit_auth(req):
    if not security.auth_limiter.allow(req.ip):
        raise ApiError(429, "rate_limited", "Слишком много попыток, подождите минуту")


# ====================================================================== status & auth
@route("GET", "/api/v1/status", public=True)
def status(req):
    return {
        "version": cfg.VERSION,
        "demo_mode": cfg.DEMO_MODE,
        "telegram": {
            "configured": bool(cfg.BOT_TOKEN),
            "connected": telegram.state["connected"],
            "username": telegram.state["username"] or cfg.BOT_USERNAME,
            "error": telegram.state["error"],
        },
        "miniapp_url": bot.miniapp_url(),
        "authenticated": req.user is not None,
    }


@route("POST", "/api/v1/auth/demo", public=True)
def auth_demo(req):
    if not cfg.DEMO_MODE:
        raise ApiError(403, "demo_disabled", "Демо-режим отключён")
    limit_auth(req)
    user = db.one("SELECT * FROM users WHERE id=?", seed.create_demo_user())
    return start_session(req, user, with_token=True)


@route("POST", "/api/v1/auth/miniapp", public=True)
def auth_miniapp(req):
    limit_auth(req)
    if not cfg.BOT_TOKEN:
        raise ApiError(400, "no_bot", "Бот не настроен (BOT_TOKEN)")
    try:
        tg_user = security.verify_init_data(need(req, "init_data"), cfg.BOT_TOKEN, cfg.INIT_DATA_MAX_AGE)
    except security.AuthError as e:
        raise ApiError(401, "bad_init_data", str(e))
    user = security.upsert_telegram_user(tg_user)
    return start_session(req, user, with_token=True)


@route("POST", "/api/v1/auth/web/start", public=True)
def web_start(req):
    limit_auth(req)
    if not telegram.is_live():
        raise ApiError(409, "telegram_not_connected",
                       "Вход через Telegram недоступен: бот не подключён. Укажите BOT_TOKEN или используйте демо-режим.")
    raw, hashed = security.new_token()
    db.insert("login_tokens", token_hash=hashed, expires_at=db.iso(db.now() + timedelta(seconds=cfg.LOGIN_TOKEN_TTL)))
    username = telegram.state["username"]
    return {"token": raw, "deep_link": f"https://t.me/{username}?start=login_{raw}", "expires_in": cfg.LOGIN_TOKEN_TTL}


@route("POST", "/api/v1/auth/web/poll", public=True)
def web_poll(req):
    token = need(req, "token")
    h = security.hash_token(token)
    row = db.one("SELECT * FROM login_tokens WHERE token_hash=?", h)
    if row is None or row["consumed"] or row["expires_at"] < db.now_iso():
        return {"status": "expired"}
    if not row["confirmed"] or row["user_id"] is None:
        return {"status": "pending"}
    cur = db.run("UPDATE login_tokens SET consumed=1 WHERE token_hash=? AND consumed=0", h)
    if cur.rowcount != 1:
        return {"status": "expired"}
    user = db.one("SELECT * FROM users WHERE id=?", row["user_id"])
    return {"status": "confirmed", **start_session(req, user)}


@route("POST", "/api/v1/auth/logout")
def logout(req):
    security.delete_session(req.session_token)
    req.clear_session()
    return {"ok": True}


# ====================================================================== me / settings
@route("GET", "/api/v1/me")
def me(req):
    db.run("UPDATE users SET last_seen_at=? WHERE id=?", db.now_iso(), req.user["id"])
    return user_dict(req.user)


@route("PUT", "/api/v1/me")
def update_me(req):
    uid = req.user["id"]
    lang = req.body.get("language", req.user["language"])
    if lang not in ("ru", "en"):
        raise ApiError(422, "validation", "Язык: ru или en")
    tz = req.body.get("timezone", req.user["timezone"])
    try:
        ZoneInfo(tz)
    except Exception:
        raise ApiError(422, "validation", "Неизвестный часовой пояс")
    notify = 1 if req.body.get("notify", bool(req.user["notify"])) else 0
    name = str(req.body.get("first_name", req.user["first_name"]))[:80]
    db.run("UPDATE users SET language=?, timezone=?, notify=?, first_name=? WHERE id=?", lang, tz, notify, name, uid)
    return user_dict(db.one("SELECT * FROM users WHERE id=?", uid))


@route("POST", "/api/v1/me/test-notification")
def test_notification(req):
    if req.user["is_demo"]:
        return {"sent": False, "reason": "Демо-пользователь: Telegram-уведомления не отправляются. Войдите через Telegram."}
    if not telegram.is_live():
        return {"sent": False, "reason": "Бот не подключён к Telegram."}
    try:
        telegram.client().send_message(req.user["telegram_id"], "🔔 Тестовое уведомление MarketPilot. Всё работает!", None)
    except (telegram.TelegramError, telegram.TelegramNetworkError) as e:
        return {"sent": False, "reason": f"Telegram: {e}. Откройте чат с ботом и нажмите /start."}
    return {"sent": True}


@route("POST", "/api/v1/me/demo-data")
def load_demo_data(req):
    """Add demo resources/posts to a real account so the interface is not empty (clearly flagged as demo)."""
    if db.one("SELECT 1 FROM resources WHERE user_id=? AND is_demo=1", req.user["id"]):
        raise ApiError(409, "already_loaded", "Демо-данные уже загружены")
    with db.tx():
        seed.seed_demo(req.user["id"])
    return {"ok": True}


@route("DELETE", "/api/v1/me/demo-data")
def remove_demo_data(req):
    uid = req.user["id"]
    with db.tx():
        ids = [r["id"] for r in db.q("SELECT id FROM resources WHERE user_id=? AND is_demo=1", uid)]
        for rid in ids:
            db.run("DELETE FROM resources WHERE id=?", rid)  # cascades to targets, snapshots, stats
        db.run("DELETE FROM posts WHERE user_id=? AND id NOT IN (SELECT post_id FROM post_targets)", uid)
        db.run("DELETE FROM events WHERE user_id=? AND resource_id IS NULL AND message LIKE '%демо%'", uid)
    return {"ok": True, "removed": len(ids)}


@route("POST", "/api/v1/me/reset-demo")
def reset_demo(req):
    if not req.user["is_demo"]:
        raise ApiError(403, "not_demo", "Только для демо-пользователя")
    uid = req.user["id"]
    with db.tx():
        for table in ("resources", "posts", "templates", "events"):
            db.run(f"DELETE FROM {table} WHERE user_id=?", uid)
        seed.seed_demo(uid)
    return {"ok": True}


@route("DELETE", "/api/v1/me")
def delete_me(req):
    """Account and data deletion (spec 21.12)."""
    db.run("DELETE FROM users WHERE id=?", req.user["id"])
    req.clear_session()
    return {"ok": True}


# ====================================================================== resources
def decorate_resources(user_id: int, rows) -> list[dict]:
    out = []
    week_ago = db.iso(db.days_ago(7))
    for r in rows:
        d = res_dict(r)
        snaps = db.q("SELECT members FROM snapshots WHERE resource_id=? AND taken_at>=? ORDER BY taken_at", r["id"], week_ago)
        d["members_delta_7d"] = snaps[-1]["members"] - snaps[0]["members"] if len(snaps) >= 2 else None
        d["published_total"] = db.one("SELECT COUNT(*) n FROM post_targets WHERE resource_id=? AND status='published'",
                                      r["id"])["n"]
        d["scheduled_count"] = db.one("SELECT COUNT(*) n FROM post_targets WHERE resource_id=? AND status='scheduled'",
                                      r["id"])["n"]
        out.append(d)
    return out


@route("GET", "/api/v1/resources")
def list_resources(req):
    uid = req.user["id"]
    sql, args = "SELECT * FROM resources WHERE user_id=?", [uid]
    if req.query.get("type"):
        types = {"channel": ("channel",), "group": ("group", "supergroup")}.get(req.query["type"], ())
        if types:
            sql += f" AND type IN ({','.join('?' * len(types))})"
            args += list(types)
    if req.query.get("status"):
        sql += " AND status=?"
        args.append(req.query["status"])
    if req.query.get("q"):
        sql += " AND (title LIKE ? OR username LIKE ?)"
        args += [f"%{req.query['q']}%"] * 2
    sql += " ORDER BY (status='disconnected'), title"
    return {"items": decorate_resources(uid, db.q(sql, *args))}


@route("GET", "/api/v1/resources/<int:id>")
def get_resource(req):
    uid = req.user["id"]
    r = resource_row(uid, req.params["id"])
    d = decorate_resources(uid, [r])[0]
    d["recent_events"] = [dict(e) for e in db.q(
        "SELECT kind, message, created_at FROM events WHERE user_id=? AND resource_id=? ORDER BY id DESC LIMIT 8",
        uid, r["id"])]
    d["automations"] = []  # stage 4
    return d


@route("POST", "/api/v1/resources/link-code")
def link_code(req):
    uid = req.user["id"]
    info = plan_info(req.user)
    if info["resources_used"] >= info["resource_limit"]:
        raise ApiError(402, "limit", f"Лимит тарифа: {info['resource_limit']} ресурсов")
    if not telegram.is_live():
        return {"live": False, "message": "Telegram-бот не подключён (нет BOT_TOKEN или нет связи). "
                "Добавьте токен в .env и перезапустите приложение — а пока можно добавить демо-ресурс."}
    code = secrets.token_hex(4).upper()
    db.insert("link_codes", code=code, user_id=uid, expires_at=db.iso(db.now() + timedelta(minutes=15)))
    return {"live": True, "code": code, "bot_username": telegram.state["username"], "expires_in": 900}


@route("GET", "/api/v1/resources/link-status")
def link_status(req):
    """Polled by the UI while waiting for /connect: returns resources connected in the last 15 minutes."""
    rows = db.q("SELECT * FROM resources WHERE user_id=? AND is_demo=0 AND connected_at>=? ORDER BY id DESC",
                req.user["id"], db.iso(db.now() - timedelta(minutes=15)))
    return {"items": [res_dict(r) for r in rows]}


@route("POST", "/api/v1/resources/demo")
def add_demo_resource(req):
    uid = req.user["id"]
    if db.one("SELECT COUNT(*) n FROM resources WHERE user_id=? AND is_demo=1", uid)["n"] >= 20:
        raise ApiError(409, "limit", "Слишком много демо-ресурсов")
    title = str(need(req, "title")).strip()[:80]
    rtype = req.body.get("type", "channel")
    if rtype not in ("channel", "group", "supergroup"):
        raise ApiError(422, "validation", "Тип: channel, group или supergroup")
    try:
        members = max(0, min(int(req.body.get("members", 1000)), 100_000_000))
    except (TypeError, ValueError):
        raise ApiError(422, "validation", "Число подписчиков должно быть числом")
    with db.tx():
        rid = seed.add_demo_resource(uid, {"title": title, "username": None, "type": rtype, "members": members,
                                           "rights": "full"})
    return res_dict(db.one("SELECT * FROM resources WHERE id=?", rid))


@route("POST", "/api/v1/resources/<int:id>/check")
def check_resource(req):
    from . import scheduler
    uid = req.user["id"]
    r = resource_row(uid, req.params["id"])
    if r["is_demo"]:
        db.run("UPDATE resources SET last_checked_at=? WHERE id=?", db.now_iso(), r["id"])
    else:
        if not telegram.is_live():
            raise ApiError(409, "telegram_not_connected", "Бот не подключён к Telegram")
        scheduler.refresh_resource(r)
    return res_dict(db.one("SELECT * FROM resources WHERE id=?", r["id"]))


@route("POST", "/api/v1/resources/<int:id>/simulate-rights")
def simulate_rights(req):
    """Demo only: toggle the 'publish' right of a demo resource to show how the product reacts to revoked rights."""
    r = resource_row(req.user["id"], req.params["id"])
    if not r["is_demo"]:
        raise ApiError(403, "not_demo", "Только для демо-ресурсов")
    caps = db.jl(r["capabilities"])
    if "publish" in caps:
        caps = [c for c in caps if c not in ("publish", "edit_messages")]
        missing, status = ["can_post_messages"], "missing_rights"
        msg = f"Права бота в «{r['title']}» изменены: не хватает can_post_messages (демо)"
    else:
        caps = ["publish", "edit_messages", "delete_messages"] if r["type"] == "channel" else \
            ["publish", "delete_messages", "restrict_members", "pin_messages"]
        missing, status = [], "active"
        msg = f"Права бота в «{r['title']}» восстановлены (демо)"
    db.run("UPDATE resources SET capabilities=?, missing_rights=?, status=?, last_checked_at=? WHERE id=?",
           json.dumps(caps), json.dumps(missing), status, db.now_iso(), r["id"])
    db.event(r["user_id"], "rights_changed", msg, r["id"])
    return res_dict(db.one("SELECT * FROM resources WHERE id=?", r["id"]))


@route("DELETE", "/api/v1/resources/<int:id>")
def disconnect_resource(req):
    uid = req.user["id"]
    r = resource_row(uid, req.params["id"])
    with db.tx():
        db.run("UPDATE resources SET status='disconnected' WHERE id=?", r["id"])
        bot.cancel_pending(r["id"], "Ресурс отключён")
        db.event(uid, "resource_disconnected", f"Ресурс «{r['title']}» отключён", r["id"])
    return {"ok": True}


@route("POST", "/api/v1/resources/<int:id>/reconnect")
def reconnect_resource(req):
    uid = req.user["id"]
    r = resource_row(uid, req.params["id"])
    if r["status"] != "disconnected":
        raise ApiError(409, "bad_state", "Ресурс уже подключён")
    if not r["is_demo"]:
        raise ApiError(409, "need_link", "Подключите ресурс заново через бота (/connect КОД)")
    db.run("UPDATE resources SET status='active' WHERE id=?", r["id"])
    return res_dict(db.one("SELECT * FROM resources WHERE id=?", r["id"]))


@route("DELETE", "/api/v1/resources/<int:id>/forget")
def forget_resource(req):
    """Remove a disconnected resource and its history for good."""
    r = resource_row(req.user["id"], req.params["id"])
    if r["status"] != "disconnected":
        raise ApiError(409, "bad_state", "Сначала отключите ресурс")
    db.run("DELETE FROM resources WHERE id=?", r["id"])
    return {"ok": True}


# ====================================================================== posts
def load_targets(post_ids: list[int]) -> dict[int, list[dict]]:
    if not post_ids:
        return {}
    marks = ",".join("?" * len(post_ids))
    rows = db.q(f"SELECT t.*, r.title AS resource_title FROM post_targets t JOIN resources r ON r.id=t.resource_id "
                f"WHERE t.post_id IN ({marks}) ORDER BY t.id", *post_ids)
    out: dict[int, list[dict]] = {}
    for t in rows:
        out.setdefault(t["post_id"], []).append(target_dict(t))
    return out


def post_dict(p, targets) -> dict:
    return {"id": p["id"], "text": p["text"], "image_url": p["image_url"], "created_at": p["created_at"],
            "updated_at": p["updated_at"], "targets": targets}


def post_row(uid: int, pid: int):
    p = db.one("SELECT * FROM posts WHERE id=? AND user_id=?", pid, uid)
    if p is None:
        raise NOT_FOUND
    return p


@route("GET", "/api/v1/posts")
def list_posts(req):
    uid = req.user["id"]
    where, args = ["p.user_id=?"], [uid]
    if req.query.get("status"):
        where.append("EXISTS(SELECT 1 FROM post_targets t WHERE t.post_id=p.id AND t.status=?)")
        args.append(req.query["status"])
    if req.query.get("resource_id", "").isdigit():
        where.append("EXISTS(SELECT 1 FROM post_targets t WHERE t.post_id=p.id AND t.resource_id=?)")
        args.append(int(req.query["resource_id"]))
    if req.query.get("q"):
        where.append("p.text LIKE ?")
        args.append(f"%{req.query['q']}%")
    cond = " AND ".join(where)
    total = db.one(f"SELECT COUNT(*) n FROM posts p WHERE {cond}", *args)["n"]
    limit, offset = req.int_param("limit", 30, 1, 100), req.int_param("offset", 0, 0, 10**7)
    rows = db.q(f"SELECT p.* FROM posts p WHERE {cond} ORDER BY p.id DESC LIMIT ? OFFSET ?", *args, limit, offset)
    tmap = load_targets([r["id"] for r in rows])
    return {"total": total, "items": [post_dict(r, tmap.get(r["id"], [])) for r in rows]}


@route("GET", "/api/v1/posts/<int:id>")
def get_post(req):
    p = post_row(req.user["id"], req.params["id"])
    return post_dict(p, load_targets([p["id"]]).get(p["id"], []))


def read_post_body(req, uid: int):
    """Validate the editor payload. Returns (text, image_url, resources, mode, when)."""
    text = str(req.body.get("text", "")).strip()
    image = validate_image(req.body.get("image_url"))
    if not text and not image:
        raise ApiError(422, "validation", "Добавьте текст или изображение")
    validate_text(text, bool(image))
    ids = req.body.get("resource_ids")
    if not isinstance(ids, list) or not ids or not all(isinstance(i, int) for i in ids):
        raise ApiError(422, "validation", "Выберите хотя бы один ресурс")
    ids = list(dict.fromkeys(ids))
    resources = []
    for rid in ids:
        r = db.one("SELECT * FROM resources WHERE id=? AND user_id=?", rid, uid)
        if r is None:
            raise NOT_FOUND
        if r["status"] == "disconnected":
            raise ApiError(422, "validation", f"Ресурс «{r['title']}» отключён")
        resources.append(r)
    mode = req.body.get("mode", "draft")
    if mode not in ("draft", "schedule", "now"):
        raise ApiError(422, "validation", "mode: draft, schedule или now")
    when = None
    if mode == "schedule":
        when = parse_when(need(req, "scheduled_at"))
        if when < db.now() - timedelta(minutes=1):
            raise ApiError(422, "past", "Время публикации уже прошло")
        if when > db.now() + timedelta(days=366):
            raise ApiError(422, "validation", "Дата слишком далеко (максимум год)")
    elif mode == "now":
        when = db.now()
    if mode != "draft":
        for r in resources:
            if r["status"] != "active" or "publish" not in db.jl(r["capabilities"]):
                raise ApiError(422, "no_rights", f"В «{r['title']}» у бота нет прав на публикацию — "
                               "исправьте права или сохраните как черновик")
    return text, image, resources, mode, when


def write_targets(uid: int, pid: int, resources, mode: str, when) -> None:
    status = "draft" if mode == "draft" else "scheduled"
    for r in resources:
        db.insert("post_targets", post_id=pid, user_id=uid, resource_id=r["id"], status=status,
                  scheduled_at=db.iso(when) if when else None)


@route("POST", "/api/v1/posts")
def create_post(req):
    uid = req.user["id"]
    text, image, resources, mode, when = read_post_body(req, uid)
    with db.tx():
        pid = db.insert("posts", user_id=uid, text=text, image_url=image, created_at=db.now_iso(), updated_at=db.now_iso())
        write_targets(uid, pid, resources, mode, when)
    p = post_row(uid, pid)
    return 201, post_dict(p, load_targets([pid])[pid])


@route("PUT", "/api/v1/posts/<int:id>")
def update_post(req):
    uid = req.user["id"]
    p = post_row(uid, req.params["id"])
    locked = db.one("SELECT 1 FROM post_targets WHERE post_id=? AND status IN ('publishing','published')", p["id"])
    if locked:
        raise ApiError(409, "locked", "Опубликованный пост нельзя изменить. Создайте копию.")
    text, image, resources, mode, when = read_post_body(req, uid)
    with db.tx():
        db.run("UPDATE posts SET text=?, image_url=?, updated_at=? WHERE id=?", text, image, db.now_iso(), p["id"])
        db.run("DELETE FROM post_targets WHERE post_id=?", p["id"])
        write_targets(uid, p["id"], resources, mode, when)
    return post_dict(post_row(uid, p["id"]), load_targets([p["id"]])[p["id"]])


@route("DELETE", "/api/v1/posts/<int:id>")
def delete_post(req):
    p = post_row(req.user["id"], req.params["id"])
    if db.one("SELECT 1 FROM post_targets WHERE post_id=? AND status='publishing'", p["id"]):
        raise ApiError(409, "busy", "Пост отправляется прямо сейчас")
    db.run("DELETE FROM posts WHERE id=?", p["id"])
    return {"ok": True}


@route("POST", "/api/v1/posts/<int:id>/duplicate")
def duplicate_post(req):
    uid = req.user["id"]
    p = post_row(uid, req.params["id"])
    with db.tx():
        pid = db.insert("posts", user_id=uid, text=p["text"], image_url=p["image_url"], created_at=db.now_iso(),
                        updated_at=db.now_iso())
        rows = db.q("SELECT DISTINCT t.resource_id FROM post_targets t JOIN resources r ON r.id=t.resource_id "
                    "WHERE t.post_id=? AND r.status!='disconnected'", p["id"])
        for r in rows:
            db.insert("post_targets", post_id=pid, user_id=uid, resource_id=r["resource_id"], status="draft")
    return 201, post_dict(post_row(uid, pid), load_targets([pid]).get(pid, []))


def target_row(uid: int, tid: int):
    t = db.one("SELECT * FROM post_targets WHERE id=? AND user_id=?", tid, uid)
    if t is None:
        raise NOT_FOUND
    return t


def _publishable(uid: int, t) -> None:
    r = db.one("SELECT * FROM resources WHERE id=?", t["resource_id"])
    if r["status"] != "active" or "publish" not in db.jl(r["capabilities"]):
        raise ApiError(422, "no_rights", f"В «{r['title']}» у бота нет прав на публикацию")


@route("POST", "/api/v1/post-targets/<int:id>/cancel")
def cancel_target(req):
    t = target_row(req.user["id"], req.params["id"])
    cur = db.run("UPDATE post_targets SET status='cancelled', error=NULL WHERE id=? AND status IN ('scheduled','draft')", t["id"])
    if cur.rowcount != 1:
        raise ApiError(409, "bad_state", f"Нельзя отменить в статусе «{t['status']}»")
    return {"ok": True}


@route("POST", "/api/v1/post-targets/<int:id>/retry")
def retry_target(req):
    """Manual retry of failed/unknown. For `unknown` the UI warns about a possible duplicate."""
    t = target_row(req.user["id"], req.params["id"])
    _publishable(req.user["id"], t)
    cur = db.run("UPDATE post_targets SET status='scheduled', scheduled_at=?, next_attempt_at=NULL, attempts=0, error=NULL "
                 "WHERE id=? AND status IN ('failed','unknown')", db.now_iso(), t["id"])
    if cur.rowcount != 1:
        raise ApiError(409, "bad_state", f"Нельзя повторить в статусе «{t['status']}»")
    return {"ok": True}


@route("POST", "/api/v1/post-targets/<int:id>/publish-now")
def publish_now(req):
    t = target_row(req.user["id"], req.params["id"])
    _publishable(req.user["id"], t)
    cur = db.run("UPDATE post_targets SET status='scheduled', scheduled_at=?, next_attempt_at=NULL, error=NULL "
                 "WHERE id=? AND status IN ('draft','scheduled','cancelled')", db.now_iso(), t["id"])
    if cur.rowcount != 1:
        raise ApiError(409, "bad_state", f"Нельзя опубликовать в статусе «{t['status']}»")
    return {"ok": True}


@route("GET", "/api/v1/targets")
def list_targets(req):
    """Flat list for the calendar: targets whose scheduled time lies in [from, to)."""
    uid = req.user["id"]
    start, end = req.query.get("from"), req.query.get("to")
    if not start or not end:
        raise ApiError(422, "validation", "Нужны параметры from и to")
    start, end = db.iso(parse_when(start)), db.iso(parse_when(end))
    sql = ("SELECT t.*, r.title AS resource_title, p.text AS text FROM post_targets t "
           "JOIN resources r ON r.id=t.resource_id JOIN posts p ON p.id=t.post_id "
           "WHERE t.user_id=? AND t.scheduled_at>=? AND t.scheduled_at<?")
    args = [uid, start, end]
    if req.query.get("resource_id", "").isdigit():
        sql += " AND t.resource_id=?"
        args.append(int(req.query["resource_id"]))
    sql += " ORDER BY t.scheduled_at LIMIT 1000"
    out = []
    for t in db.q(sql, *args):
        d = target_dict(t)
        d["text"] = re.sub(r"<[^>]+>", "", t["text"])[:140]
        out.append(d)
    return {"items": out}


# ====================================================================== templates
@route("GET", "/api/v1/templates")
def list_templates(req):
    return {"items": [dict(r) for r in db.q(
        "SELECT id, name, text, created_at FROM templates WHERE user_id=? ORDER BY id DESC", req.user["id"])]}


@route("POST", "/api/v1/templates")
def create_template(req):
    name = str(need(req, "name")).strip()[:80]
    text = str(need(req, "text")).strip()
    validate_text(text, False)
    tid = db.insert("templates", user_id=req.user["id"], name=name, text=text, created_at=db.now_iso())
    return 201, dict(db.one("SELECT id, name, text, created_at FROM templates WHERE id=?", tid))


@route("DELETE", "/api/v1/templates/<int:id>")
def delete_template(req):
    cur = db.run("DELETE FROM templates WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if cur.rowcount != 1:
        raise NOT_FOUND
    return {"ok": True}


# ====================================================================== analytics & dashboard
def local_day(iso_str: str, tz: ZoneInfo) -> str:
    return db.parse_iso(iso_str).astimezone(tz).strftime("%Y-%m-%d")


def day_labels(days: int, tz: ZoneInfo) -> list[str]:
    today = datetime.now(tz).date()
    return [(today - timedelta(days=i)).isoformat() for i in range(days - 1, -1, -1)]


def member_series(resource_ids: list[int], labels: list[str], tz: ZoneInfo) -> dict[int, list]:
    """Per resource: last snapshot of each local day, forward-filled; None before the first snapshot."""
    result = {}
    since = db.iso(db.now() - timedelta(days=len(labels) + 2))
    for rid in resource_ids:
        by_day = {}
        for s in db.q("SELECT members, taken_at FROM snapshots WHERE resource_id=? AND taken_at>=? ORDER BY taken_at", rid, since):
            by_day[local_day(s["taken_at"], tz)] = s["members"]
        prior = db.one("SELECT members FROM snapshots WHERE resource_id=? AND taken_at<? ORDER BY taken_at DESC LIMIT 1", rid, since)
        last = prior["members"] if prior else None
        series = []
        for d in labels:
            last = by_day.get(d, last)
            series.append(last)
        result[rid] = series
    return result


def total_series(series: dict[int, list], n: int) -> list:
    out = []
    for i in range(n):
        vals = [s[i] for s in series.values() if s[i] is not None]
        out.append(sum(vals) if vals else None)
    return out


def growth(series: dict[int, list]):
    delta, base = 0, 0
    for s in series.values():
        vals = [v for v in s if v is not None]
        if len(vals) >= 2 and s[0] is not None:  # only resources with data at the window start
            delta += vals[-1] - vals[0]
            base += vals[0]
    return delta, (round(delta / base * 100, 2) if base else None)


def published_per_day(uid: int, labels: list[str], tz: ZoneInfo, resource_ids=None) -> list[int]:
    sql = "SELECT published_at FROM post_targets WHERE user_id=? AND status='published' AND published_at>=?"
    args = [uid, db.iso(db.now() - timedelta(days=len(labels) + 2))]
    if resource_ids is not None:
        sql += f" AND resource_id IN ({','.join('?' * len(resource_ids)) or 'NULL'})"
        args += resource_ids
    counts = {d: 0 for d in labels}
    for r in db.q(sql, *args):
        d = local_day(r["published_at"], tz)
        if d in counts:
            counts[d] += 1
    return [counts[d] for d in labels]


def selected_resources(uid: int, rid_param: str):
    rows = db.q("SELECT * FROM resources WHERE user_id=? AND status!='disconnected' ORDER BY title", uid)
    if rid_param.isdigit():
        rows = [r for r in rows if r["id"] == int(rid_param)]
        if not rows:
            raise NOT_FOUND
    return rows


def source_label(rows) -> str:
    live = any(not r["is_demo"] for r in rows)
    demo = any(r["is_demo"] for r in rows)
    parts = []
    if live:
        parts.append("Telegram Bot API: getChatMemberCount, снимки MarketPilot")
    if demo:
        parts.append("демо-данные (сгенерированы)")
    return "; ".join(parts) or "нет данных"


@route("GET", "/api/v1/dashboard")
def dashboard(req):
    uid, tz = req.user["id"], user_tz(req.user)
    days = req.int_param("days", 30, 1, 90)
    rows = selected_resources(uid, req.query.get("resource_id", ""))
    if req.query.get("type") in ("channel", "group"):
        want = ("channel",) if req.query["type"] == "channel" else ("group", "supergroup")
        rows = [r for r in rows if r["type"] in want]
    ids = [r["id"] for r in rows]
    labels = day_labels(days, tz)
    series = member_series(ids, labels, tz)
    totals = total_series(series, len(labels))
    delta, pct = growth(series)
    since = db.iso(db.now() - timedelta(days=days))
    marks = ",".join("?" * len(ids)) or "NULL"

    def count(extra: str, *args) -> int:
        return db.one(f"SELECT COUNT(*) n FROM post_targets WHERE user_id=? AND resource_id IN ({marks}) AND {extra}",
                      uid, *ids, *args)["n"]

    published = count("status='published' AND published_at>=?", since)
    upcoming = count("status='scheduled'")
    attention_targets = count("status IN ('failed','unknown') AND scheduled_at>=?", since)
    attention_res = sum(1 for r in rows if r["status"] == "missing_rights")
    ev_sql = "SELECT * FROM events WHERE user_id=?"
    ev_args = [uid]
    if req.query.get("kind"):
        ev_sql += " AND kind=?"
        ev_args.append(req.query["kind"])
    events = [dict(e) for e in db.q(ev_sql + " ORDER BY id DESC LIMIT 12", *ev_args)]
    upcoming_list = [dict(t, text=re.sub(r"<[^>]+>", "", t["text"])[:100]) for t in db.q(
        "SELECT t.id, t.post_id, t.scheduled_at, t.status, r.title AS resource_title, p.text AS text FROM post_targets t "
        "JOIN resources r ON r.id=t.resource_id JOIN posts p ON p.id=t.post_id "
        f"WHERE t.user_id=? AND t.status='scheduled' AND t.resource_id IN ({marks}) ORDER BY t.scheduled_at LIMIT 5",
        uid, *ids)]
    src = source_label(rows)
    return {
        "period_days": days, "labels": labels,
        "kpis": {
            "channels": {"value": sum(1 for r in rows if r["type"] == "channel"), "source": "MarketPilot"},
            "groups": {"value": sum(1 for r in rows if r["type"] != "channel"), "source": "MarketPilot"},
            "members": {"value": sum(r["members"] or 0 for r in rows), "source": src, "period": "сейчас",
                        "delta": delta, "delta_pct": pct},
            "published": {"value": published, "source": "журнал публикаций MarketPilot", "period": f"{days} дн."},
            "scheduled": {"value": upcoming, "source": "планировщик MarketPilot", "period": "впереди"},
            "attention": {"value": attention_targets + attention_res, "source": "журнал публикаций и проверка прав",
                          "period": f"{days} дн."},
        },
        "members_series": totals,
        "published_series": published_per_day(uid, labels, tz, ids),
        "events": events, "upcoming": upcoming_list,
        "views_available": False,
        "views_note": "Просмотры публикаций недоступны через Telegram Bot API и не отображаются.",
    }


@route("GET", "/api/v1/analytics")
def analytics(req):
    uid, tz = req.user["id"], user_tz(req.user)
    days = req.int_param("days", 30, 1, 90)
    rows = selected_resources(uid, req.query.get("resource_id", ""))
    ids = [r["id"] for r in rows]
    labels = day_labels(days, tz)
    series = member_series(ids, labels, tz)
    delta, pct = growth(series)
    since = db.iso(db.now() - timedelta(days=days))

    table = []
    for r in rows:
        s = series[r["id"]]
        vals = [v for v in s if v is not None]
        counts = {k: db.one("SELECT COUNT(*) n FROM post_targets WHERE resource_id=? AND status=? AND scheduled_at>=?",
                            r["id"], k, since)["n"] for k in ("published", "failed", "unknown")}
        finished = sum(counts.values())
        table.append({
            "id": r["id"], "title": r["title"], "type": r["type"], "is_demo": bool(r["is_demo"]),
            "members": r["members"], "delta": vals[-1] - vals[0] if len(vals) >= 2 and s[0] is not None else None,
            "published": counts["published"], "failed": counts["failed"], "unknown": counts["unknown"],
            "success_rate": round(counts["published"] / finished * 100) if finished else None,
        })

    hours = [0] * 24
    weekdays = [0] * 7
    sql = (f"SELECT published_at FROM post_targets WHERE user_id=? AND status='published' AND published_at>=? "
           f"AND resource_id IN ({','.join('?' * len(ids)) or 'NULL'})")
    for r in db.q(sql, uid, since, *ids):
        local = db.parse_iso(r["published_at"]).astimezone(tz)
        hours[local.hour] += 1
        weekdays[local.weekday()] += 1

    groups = [r for r in rows if r["type"] != "channel"]
    activity = None
    if groups:
        agg = {d: [0, 0, 0] for d in labels}
        for g in groups:
            for s in db.q("SELECT day, messages, joins, leaves FROM group_stats WHERE resource_id=?", g["id"]):
                if s["day"] in agg:
                    agg[s["day"]][0] += s["messages"]
                    agg[s["day"]][1] += s["joins"]
                    agg[s["day"]][2] += s["leaves"]
        activity = {"messages": [agg[d][0] for d in labels], "joins": [agg[d][1] for d in labels],
                    "leaves": [agg[d][2] for d in labels], "groups": len(groups),
                    "source": "события бота (счётчики; тексты сообщений не хранятся)"}

    tips = []
    if sum(hours) >= 5:
        best = max(range(24), key=lambda h: hours[h])
        tips.append(f"Чаще всего публикации выходят в {best:02d}:00 — это ваше «привычное» окно.")
    failed_total = sum(t["failed"] + t["unknown"] for t in table)
    if failed_total:
        tips.append(f"За период {failed_total} публикаций завершились ошибкой или без подтверждения — проверьте раздел «Публикации».")
    if any(r["status"] == "missing_rights" for r in rows):
        tips.append("В части ресурсов боту не хватает прав — публикации туда блокируются.")
    return {
        "period_days": days, "labels": labels, "source": source_label(rows),
        "members_series": total_series(series, len(labels)),
        "members_by_resource": [{"id": r["id"], "title": r["title"], "values": series[r["id"]]} for r in rows],
        "growth": {"delta": delta, "pct": pct},
        "published_series": published_per_day(uid, labels, tz, ids),
        "table": table, "hours": hours, "weekdays": weekdays, "group_activity": activity, "tips": tips,
        "limitations": ["Просмотры постов и охваты недоступны через Telegram Bot API — они не показываются и не оцениваются.",
                        "Динамика подписчиков строится по снимкам getChatMemberCount, которые делает MarketPilot "
                        f"(раз в {cfg.SNAPSHOT_INTERVAL_MIN // 60} ч); история до подключения ресурса недоступна.",
                        "Активность групп считается по событиям, которые видит бот (нужны права администратора)."],
    }


@route("GET", "/api/v1/notifications")
def notifications(req):
    """Event feed with unread tracking (users.notif_seen = id of the last event the user has seen)."""
    uid = req.user["id"]
    seen = db.one("SELECT notif_seen FROM users WHERE id=?", uid)["notif_seen"]
    rows = db.q("SELECT id, kind, message, resource_id, created_at FROM events WHERE user_id=? ORDER BY id DESC LIMIT ?",
                uid, req.int_param("limit", 50, 1, 200))
    unread = db.one("SELECT COUNT(*) n FROM events WHERE user_id=? AND id>?", uid, seen)["n"]
    return {"unread": unread, "notify": bool(req.user["notify"]),
            "items": [dict(r, unread=r["id"] > seen) for r in rows]}


@route("POST", "/api/v1/notifications/read")
def notifications_read(req):
    uid = req.user["id"]
    top = db.one("SELECT COALESCE(MAX(id), 0) m FROM events WHERE user_id=?", uid)["m"]
    db.run("UPDATE users SET notif_seen=? WHERE id=?", top, uid)
    return {"ok": True, "unread": 0}


@route("GET", "/api/v1/events")
def list_events(req):
    uid = req.user["id"]
    sql, args = "SELECT * FROM events WHERE user_id=?", [uid]
    if req.query.get("kind"):
        sql += " AND kind=?"
        args.append(req.query["kind"])
    sql += " ORDER BY id DESC LIMIT ?"
    args.append(req.int_param("limit", 50, 1, 200))
    return {"items": [dict(e) for e in db.q(sql, *args)]}
