"""Telegram auth primitives, session tokens, tiny in-memory rate limiter."""
import hashlib
import hmac
import json
import secrets
import threading
import time
from collections import defaultdict, deque
from urllib.parse import parse_qsl

from . import db
from .config import cfg


class AuthError(Exception):
    pass


def verify_init_data(init_data: str, bot_token: str, max_age: int) -> dict:
    """Validate Mini App initData (https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app)."""
    if not init_data or not bot_token:
        raise AuthError("empty init data")
    pairs = dict(parse_qsl(init_data, keep_blank_values=True))
    received = pairs.pop("hash", None)
    if not received:
        raise AuthError("hash is missing")
    check = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, received):
        raise AuthError("invalid signature")
    try:
        auth_date = int(pairs.get("auth_date", "0"))
    except ValueError:
        raise AuthError("bad auth_date")
    if auth_date <= 0 or time.time() - auth_date > max_age:
        raise AuthError("init data expired")
    if auth_date - time.time() > 60:
        raise AuthError("auth_date is in the future")
    try:
        user = json.loads(pairs["user"])
        int(user["id"])
    except (KeyError, ValueError, TypeError):
        raise AuthError("user is missing")
    return user


def hash_token(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()


def new_token() -> tuple[str, str]:
    raw = secrets.token_urlsafe(32)
    return raw, hash_token(raw)


def create_session(user_id: int) -> str:
    raw, hashed = new_token()
    now = db.now()
    db.insert("sessions", token_hash=hashed, user_id=user_id, created_at=db.iso(now),
              expires_at=db.iso(now + db.timedelta(days=cfg.SESSION_DAYS)))
    return raw


def user_for_session(raw: str):
    if not raw:
        return None
    row = db.one(
        "SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash=? AND s.expires_at>?",
        hash_token(raw), db.now_iso(),
    )
    return row


def delete_session(raw: str) -> None:
    db.run("DELETE FROM sessions WHERE token_hash=?", hash_token(raw))


def upsert_telegram_user(tg_user: dict):
    """Create or update a user from a Telegram `user` object. Returns the users row."""
    tg_id = int(tg_user["id"])
    lang = "ru" if str(tg_user.get("language_code", "ru")).startswith("ru") else "en"
    row = db.one("SELECT * FROM users WHERE telegram_id=?", tg_id)
    if row is None:
        uid = db.insert("users", telegram_id=tg_id, first_name=tg_user.get("first_name", ""),
                        username=tg_user.get("username"), language=lang, plan=cfg.DEFAULT_PLAN,
                        created_at=db.now_iso(), last_seen_at=db.now_iso())
    else:
        uid = row["id"]
        db.run("UPDATE users SET first_name=?, username=?, last_seen_at=? WHERE id=?",
               tg_user.get("first_name", row["first_name"]), tg_user.get("username"), db.now_iso(), uid)
    return db.one("SELECT * FROM users WHERE id=?", uid)


class RateLimiter:
    def __init__(self, limit: int, per_seconds: int):
        self.limit, self.per = limit, per_seconds
        self._hits: dict[str, deque] = defaultdict(deque)
        self._lock = threading.Lock()

    def allow(self, key: str) -> bool:
        now = time.monotonic()
        with self._lock:
            hits = self._hits[key]
            while hits and now - hits[0] > self.per:
                hits.popleft()
            if len(hits) >= self.limit:
                return False
            hits.append(now)
            return True


auth_limiter = RateLimiter(30, 60)
