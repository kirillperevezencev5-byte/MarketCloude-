"""SQLite storage. One connection per thread, WAL mode, schema created on start.

Tenant model for v0.1: one workspace per user, so `user_id` is the tenant key on every table.
Every query in api.py filters by the session user's id.
"""
import json
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .config import cfg

_local = threading.local()

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id INTEGER UNIQUE,
  first_name TEXT NOT NULL DEFAULT '',
  username TEXT,
  language TEXT NOT NULL DEFAULT 'ru',
  timezone TEXT NOT NULL DEFAULT 'Europe/Moscow',
  is_demo INTEGER NOT NULL DEFAULT 0,
  notify INTEGER NOT NULL DEFAULT 1,
  notif_seen INTEGER NOT NULL DEFAULT 0,
  plan TEXT NOT NULL DEFAULT 'beta',
  created_at TEXT NOT NULL,
  last_seen_at TEXT
);
CREATE TABLE IF NOT EXISTS sessions(
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS login_tokens(
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  confirmed INTEGER NOT NULL DEFAULT 0,
  consumed INTEGER NOT NULL DEFAULT 0,
  expires_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS resources(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  chat_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  username TEXT,
  type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  capabilities TEXT NOT NULL DEFAULT '[]',
  missing_rights TEXT NOT NULL DEFAULT '[]',
  is_demo INTEGER NOT NULL DEFAULT 0,
  members INTEGER,
  connected_at TEXT NOT NULL,
  last_checked_at TEXT,
  UNIQUE(user_id, chat_id)
);
CREATE INDEX IF NOT EXISTS ix_resources_chat ON resources(chat_id);
CREATE TABLE IF NOT EXISTS link_codes(
  code TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  used INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS posts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  text TEXT NOT NULL DEFAULT '',
  image_url TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS post_targets(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  scheduled_at TEXT,
  attempts INTEGER NOT NULL DEFAULT 0,
  next_attempt_at TEXT,
  message_id INTEGER,
  error TEXT,
  published_at TEXT,
  started_at TEXT,
  UNIQUE(post_id, resource_id)
);
CREATE INDEX IF NOT EXISTS ix_targets_due ON post_targets(status, scheduled_at);
CREATE TABLE IF NOT EXISTS templates(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  text TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS snapshots(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  members INTEGER NOT NULL,
  taken_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_snap ON snapshots(resource_id, taken_at);
CREATE TABLE IF NOT EXISTS group_stats(
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  day TEXT NOT NULL,
  messages INTEGER NOT NULL DEFAULT 0,
  joins INTEGER NOT NULL DEFAULT 0,
  leaves INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(resource_id, day)
);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER REFERENCES resources(id) ON DELETE SET NULL,
  kind TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_events_user ON events(user_id, created_at);
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
"""


def now() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def now_iso() -> str:
    return iso(now())


def parse_iso(s: str) -> datetime:
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


def conn() -> sqlite3.Connection:
    c = getattr(_local, "conn", None)
    if c is None:
        Path(cfg.DB_PATH).parent.mkdir(parents=True, exist_ok=True)
        c = sqlite3.connect(cfg.DB_PATH, timeout=30, isolation_level=None)  # autocommit; use tx() for groups
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA foreign_keys=ON")
        c.execute("PRAGMA busy_timeout=30000")
        _local.conn = c
    return c


def close_thread() -> None:
    """Close this thread's connection (HTTP handler threads are short-lived)."""
    c = getattr(_local, "conn", None)
    if c is not None:
        try:
            c.close()
        finally:
            _local.conn = None


def init() -> None:
    conn().executescript(SCHEMA)
    # lightweight migrations for databases created by earlier versions
    cols = {r["name"] for r in conn().execute("PRAGMA table_info(users)")}
    if "notif_seen" not in cols:
        conn().execute("ALTER TABLE users ADD COLUMN notif_seen INTEGER NOT NULL DEFAULT 0")


class tx:
    """with db.tx(): ...  -> BEGIN IMMEDIATE ... COMMIT / ROLLBACK."""

    def __enter__(self):
        conn().execute("BEGIN IMMEDIATE")

    def __exit__(self, exc_type, exc, tb):
        conn().execute("ROLLBACK" if exc_type else "COMMIT")
        return False


def q(sql: str, *args) -> list[sqlite3.Row]:
    return conn().execute(sql, args).fetchall()


def one(sql: str, *args):
    return conn().execute(sql, args).fetchone()


def run(sql: str, *args) -> sqlite3.Cursor:
    return conn().execute(sql, args)


def insert(table: str, **values) -> int:
    cols = ", ".join(values)
    marks = ", ".join("?" for _ in values)
    cur = conn().execute(f"INSERT INTO {table}({cols}) VALUES({marks})", tuple(values.values()))
    return cur.lastrowid


def get_meta(key: str, default=None):
    row = one("SELECT value FROM meta WHERE key=?", key)
    return row["value"] if row else default


def set_meta(key: str, value) -> None:
    run("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", key, str(value))


def jl(value) -> list:
    return json.loads(value) if value else []


def event(user_id: int, kind: str, message: str, resource_id: int | None = None) -> None:
    insert("events", user_id=user_id, resource_id=resource_id, kind=kind, message=message, created_at=now_iso())


def days_ago(n: int) -> datetime:
    return now() - timedelta(days=n)
