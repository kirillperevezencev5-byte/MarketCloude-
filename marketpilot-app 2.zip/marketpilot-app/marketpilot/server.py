"""Tiny HTTP framework on top of http.server: JSON routes, cookie/bearer sessions, static files, security headers."""
import json
import logging
import mimetypes
import re
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import db, security
from .config import ROOT, cfg

log = logging.getLogger("marketpilot.http")
STATIC = ROOT / "static"
COOKIE = "mp_session"

ROUTES: list[tuple[str, re.Pattern, callable, bool]] = []


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str = ""):
        super().__init__(message or code)
        self.status, self.code, self.message = status, code, message or code


def route(method: str, path: str, public: bool = False):
    pattern = re.compile("^" + re.sub(r"<int:(\w+)>", r"(?P<\1>\\d+)", path) + "$")

    def deco(fn):
        ROUTES.append((method, pattern, fn, public))
        return fn

    return deco


class Request:
    def __init__(self, handler: BaseHTTPRequestHandler, method: str, url):
        self.handler = handler
        self.method = method
        self.path = url.path
        self.query = {k: v[0] for k, v in parse_qs(url.query).items()}
        self.headers = handler.headers
        self.ip = handler.client_address[0]
        self.body: dict = {}
        self.user = None
        self.params: dict = {}
        self.new_cookies: list[str] = []
        self.session_token = ""

    def int_param(self, name: str, default: int, lo: int, hi: int) -> int:
        try:
            value = int(self.query.get(name, default))
        except ValueError:
            value = default
        return max(lo, min(hi, value))

    def set_session(self, raw: str) -> None:
        parts = [f"{COOKIE}={raw}", "Path=/", "HttpOnly", "SameSite=Lax", f"Max-Age={cfg.SESSION_DAYS * 86400}"]
        if cfg.COOKIE_SECURE:
            parts.append("Secure")
        self.new_cookies.append("; ".join(parts))

    def clear_session(self) -> None:
        self.new_cookies.append(f"{COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0")


def _read_cookie(header: str, name: str) -> str:
    for part in (header or "").split(";"):
        k, _, v = part.strip().partition("=")
        if k == name:
            return v
    return ""


CSP = ("default-src 'self'; script-src 'self' https://telegram.org; style-src 'self' 'unsafe-inline'; "
       "img-src 'self' data: https: http:; connect-src 'self'; "
       "frame-ancestors 'self' https://web.telegram.org https://*.telegram.org")


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "MarketPilot"

    def log_message(self, fmt, *args):  # quieter default logging
        log.debug("%s %s", self.address_string(), fmt % args)

    def handle(self):
        try:
            super().handle()
        finally:
            db.close_thread()  # one short-lived thread per connection: release its SQLite handle

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_DELETE(self):
        self._dispatch("DELETE")

    # ---- core ----
    def _dispatch(self, method: str):
        url = urlparse(self.path)
        if not url.path.startswith("/api/"):
            if method != "GET":
                return self._json(405, {"error": "method_not_allowed"})
            return self._static(url.path)
        req = Request(self, method, url)
        try:
            self._check_origin()
            for m, pattern, fn, public in ROUTES:
                if m != method:
                    continue
                match = pattern.match(url.path)
                if not match:
                    continue
                req.params = {k: int(v) for k, v in match.groupdict().items()}
                self._read_body(req)
                token = ""
                auth = self.headers.get("Authorization", "")
                if auth.lower().startswith("bearer "):
                    token = auth[7:].strip()
                req.session_token = token or _read_cookie(self.headers.get("Cookie", ""), COOKIE)
                row = security.user_for_session(req.session_token)
                if row is not None:
                    req.user = row
                if not public and req.user is None:
                    raise ApiError(401, "unauthorized", "Требуется вход")
                result = fn(req)
                status, payload = result if isinstance(result, tuple) else (200, result)
                return self._json(status, payload, req.new_cookies)
            raise ApiError(404, "not_found", "Not found")
        except ApiError as e:
            self._json(e.status, {"error": e.code, "message": e.message}, req.new_cookies)
        except Exception:
            log.error("unhandled error: %s", traceback.format_exc())
            self._json(500, {"error": "internal", "message": "Internal error"})

    def _check_origin(self):
        origin = self.headers.get("Origin")
        if origin and self.command != "GET":
            host = self.headers.get("Host", "")
            if urlparse(origin).netloc != host and not (cfg.PUBLIC_URL and origin.rstrip("/") == cfg.PUBLIC_URL):
                raise ApiError(403, "bad_origin", "Cross-origin request rejected")

    def _read_body(self, req: Request):
        length = int(self.headers.get("Content-Length") or 0)
        if length > 1_000_000:
            raise ApiError(413, "too_large", "Request too large")
        if length == 0:
            return
        raw = self.rfile.read(length)
        if "application/json" not in (self.headers.get("Content-Type") or ""):
            raise ApiError(415, "bad_content_type", "JSON required")
        try:
            body = json.loads(raw)
        except ValueError:
            raise ApiError(400, "bad_json", "Invalid JSON")
        if not isinstance(body, dict):
            raise ApiError(400, "bad_json", "JSON object expected")
        req.body = body

    def _headers(self, extra=None):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Content-Security-Policy", CSP)
        for c in extra or []:
            self.send_header("Set-Cookie", c)

    def _json(self, status: int, payload, cookies=None):
        data = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self._headers(cookies)
        self.end_headers()
        self.wfile.write(data)

    def _static(self, path: str):
        if path == "/app":
            self.send_response(301)
            self.send_header("Location", "/app/")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        rel = path.lstrip("/") or "index.html"
        target = (STATIC / rel).resolve()
        if target.is_dir():
            target = target / "index.html"
        if STATIC.resolve() not in target.parents and target != STATIC.resolve():
            return self._json(404, {"error": "not_found"})
        if not target.is_file():
            if "." in Path(rel).name:  # missing asset
                return self._json(404, {"error": "not_found"})
            target = STATIC / "index.html"  # SPA fallback
        data = target.read_bytes()
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        if target.suffix in (".js", ".css", ".html", ".svg"):
            ctype += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self._headers()
        self.end_headers()
        self.wfile.write(data)


def make_server() -> ThreadingHTTPServer:
    srv = ThreadingHTTPServer((cfg.HOST, cfg.PORT), Handler)
    srv.daemon_threads = True
    return srv


def serve_in_thread(srv: ThreadingHTTPServer) -> threading.Thread:
    t = threading.Thread(target=srv.serve_forever, name="http", daemon=True)
    t.start()
    return t
