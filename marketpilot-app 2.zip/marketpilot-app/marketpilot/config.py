"""Configuration: environment variables, optionally loaded from a .env file next to run.py."""
import os
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent


def _load_dotenv(path: pathlib.Path) -> None:
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key.strip(), value)  # real environment wins over .env


if os.environ.get("MP_NO_DOTENV") != "1":
    _load_dotenv(ROOT / ".env")


def _bool(name: str, default: bool) -> bool:
    return os.environ.get(name, "1" if default else "0").strip().lower() in ("1", "true", "yes", "on")


class Config:
    VERSION = "0.1.0"
    HOST = os.environ.get("HOST", "127.0.0.1")
    PORT = int(os.environ.get("PORT", "8000"))
    DB_PATH = os.environ.get("DB_PATH", str(ROOT / "data" / "marketpilot.db"))

    BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
    BOT_USERNAME = os.environ.get("BOT_USERNAME", "").strip().lstrip("@")
    TG_API_BASE = os.environ.get("TG_API_BASE", "https://api.telegram.org").rstrip("/")
    PUBLIC_URL = os.environ.get("PUBLIC_URL", "").rstrip("/")

    DEMO_MODE = _bool("DEMO_MODE", True)
    COOKIE_SECURE = _bool("COOKIE_SECURE", False)  # set to 1 behind HTTPS
    SESSION_DAYS = int(os.environ.get("SESSION_DAYS", "30"))
    INIT_DATA_MAX_AGE = int(os.environ.get("INIT_DATA_MAX_AGE", str(24 * 3600)))
    LOGIN_TOKEN_TTL = 300

    SNAPSHOT_INTERVAL_MIN = int(os.environ.get("SNAPSHOT_INTERVAL_MIN", "360"))
    DEFAULT_PLAN = os.environ.get("DEFAULT_PLAN", "beta")

    # Telegram limits (Bot FAQ): ~30 msg/s overall, ~1 msg/s per chat
    TG_GLOBAL_RPS = 25
    TG_CHAT_INTERVAL = 1.1
    MAX_TEXT = 4096
    MAX_CAPTION = 1024


cfg = Config

PLANS = {
    "free": {"price": 0, "resources": 1},
    "starter": {"price": 490, "resources": 3},
    "beta": {"price": 0, "resources": 10},  # beta: Pro limits for free while billing is not implemented
    "pro": {"price": 1490, "resources": 10},
    "business": {"price": 2990, "resources": 30},
    "agency": {"price": 5990, "resources": 100},
}
