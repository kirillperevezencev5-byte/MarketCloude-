"""Demo data. Demo resources are flagged is_demo=1: publishing to them is simulated, nothing reaches Telegram."""
import json
import random
from datetime import timedelta

from . import db

DEMO_PRESETS = [
    {"title": "Крипто-Новости", "username": "crypto_news_demo", "type": "channel", "members": 48210, "rights": "full"},
    {"title": "Кофейня на Арбате", "username": "arbat_coffee_demo", "type": "channel", "members": 5340, "rights": "no_post"},
    {"title": "Чат разработчиков", "username": "dev_chat_demo", "type": "supergroup", "members": 12480, "rights": "full"},
    {"title": "Клуб книголюбов", "username": "book_club_demo", "type": "group", "members": 2190, "rights": "full"},
]

CHANNEL_CAPS = ["publish", "edit_messages", "delete_messages"]
GROUP_CAPS = ["publish", "delete_messages", "restrict_members", "pin_messages"]


def _day(dt) -> str:
    return dt.strftime("%Y-%m-%d")


def add_demo_resource(user_id: int, preset: dict, history_days: int = 90, rng: random.Random | None = None) -> int:
    rng = rng or random.Random()
    is_channel = preset["type"] == "channel"
    caps = list(CHANNEL_CAPS if is_channel else GROUP_CAPS)
    missing: list[str] = []
    status = "active"
    if preset.get("rights") == "no_post":
        caps = [c for c in caps if c not in ("publish", "edit_messages")]
        missing = ["can_post_messages"]
        status = "missing_rights"
    chat_id = -(10**12) - rng.randint(10**6, 10**9)  # fake negative chat id, never a real chat
    rid = db.insert(
        "resources", user_id=user_id, chat_id=chat_id, title=preset["title"], username=preset.get("username"),
        type=preset["type"], status=status, capabilities=json.dumps(caps), missing_rights=json.dumps(missing),
        is_demo=1, members=preset["members"], connected_at=db.now_iso(), last_checked_at=db.now_iso(),
    )
    # member history: random walk ending at `members`
    value = preset["members"]
    points = []
    for d in range(history_days):
        points.append((d, value))
        value = max(10, int(value / (1 + rng.uniform(-0.002, 0.009))))
    for d, v in points:
        db.insert("snapshots", resource_id=rid, members=v, taken_at=db.iso(db.days_ago(d).replace(hour=6, minute=0, second=0)))
    if not is_channel:
        for d in range(history_days):
            base = preset["members"] // 60
            db.run(
                "INSERT INTO group_stats(resource_id,day,messages,joins,leaves) VALUES(?,?,?,?,?)",
                rid, _day(db.days_ago(d)), int(base * rng.uniform(0.5, 1.5)), rng.randint(3, 40), rng.randint(1, 25),
            )
    db.event(user_id, "resource_connected", f"Подключён демо-ресурс «{preset['title']}»", rid)
    return rid


def _post(user_id, text, targets, image_url=None, created_days_ago=0):
    created = db.iso(db.days_ago(created_days_ago))
    pid = db.insert("posts", user_id=user_id, text=text, image_url=image_url, created_at=created, updated_at=created)
    for resource_id, status, when, extra in targets:
        db.insert("post_targets", post_id=pid, user_id=user_id, resource_id=resource_id, status=status,
                  scheduled_at=when, **extra)
    return pid


def seed_demo(user_id: int) -> None:
    rng = random.Random(user_id * 7919 + 13)
    ids = [add_demo_resource(user_id, p, rng=rng) for p in DEMO_PRESETS]
    crypto, coffee, devchat, books = ids
    now = db.now()

    def at(days=0, hours=0):
        return db.iso(now + timedelta(days=days, hours=hours))

    published_texts = [
        ("<b>Биткоин обновил максимум недели</b>\nРазбираем, что стоит за ростом и чего ждать дальше.", crypto),
        ("☕ <b>Новый сезонный раф</b> — тыква и корица. Только до конца месяца!", coffee),
        ("Итоги недели в разработке: релизы, статьи и вакансии.", devchat),
        ("📚 Книга месяца: голосуем в комментариях!", books),
        ("<i>Утренний обзор рынка</i>: главное за 2 минуты.", crypto),
        ("Скидка 20% на второй напиток по пятницам.", coffee),
        ("Правила чата обновлены. Пожалуйста, прочитайте закреплённое сообщение.", devchat),
        ("Встреча клуба в четверг в 19:00. Приходите!", books),
    ]
    for i, (text, rid) in enumerate(published_texts):
        d = 1 + i * 3 % 25
        when = db.iso(now - timedelta(days=d, hours=i))
        status = "published"
        extra = {"message_id": 1000 + i, "published_at": when, "attempts": 1}
        if rid == coffee:  # the coffee channel lacks rights, but older posts went out before they were revoked
            pass
        _post(user_id, text, [(rid, status, when, extra)], created_days_ago=d)

    # a failed and an uncertain publication to show error handling
    when = db.iso(now - timedelta(hours=5))
    _post(user_id, "Пост с ошибкой форматирования <b>без закрытия", [(
        crypto, "failed", when,
        {"attempts": 1, "error": "400: Bad Request: can't parse entities: Unclosed start tag at byte offset 48"})],
        created_days_ago=0)
    when = db.iso(now - timedelta(hours=2))
    _post(user_id, "Анонс эфира с экспертом", [(
        devchat, "unknown", when,
        {"attempts": 1, "error": "no response from Telegram (TimeoutError); message may have been sent — check the chat before resending"})],
        created_days_ago=0)

    # upcoming scheduled posts (one multi-resource) and drafts
    _post(user_id, "☀️ <b>Доброе утро!</b> Подборка новостей дня уже в канале.",
          [(crypto, "scheduled", at(0, 3), {}), (books, "scheduled", at(0, 3), {})])
    _post(user_id, "Запускаем конкурс: расскажите про вашу любимую книгу и выиграйте подарок.",
          [(books, "scheduled", at(1, 2), {})])
    _post(user_id, "Еженедельный дайджест: статьи, инструменты, вакансии.", [(devchat, "scheduled", at(2, 5), {})])
    _post(user_id, "Черновик: анонс нового меню на следующую неделю.", [(crypto, "draft", None, {})])
    _post(user_id, "Идея: опрос подписчиков о форматах контента.", [(devchat, "draft", None, {})])

    db.insert("templates", user_id=user_id, name="Утренний дайджест",
              text="☀️ <b>Доброе утро!</b>\n\nГлавное за сутки:\n• \n• \n• ", created_at=db.now_iso())
    db.insert("templates", user_id=user_id, name="Анонс события",
              text="📅 <b>Анонс</b>\n\nКогда: \nГде: \n\n<a href=\"https://example.com\">Подробности</a>", created_at=db.now_iso())

    db.event(user_id, "publish_failed", "Ошибка публикации в «Крипто-Новости»: can't parse entities", crypto)
    db.event(user_id, "publish_unknown", "Нет ответа от Telegram при отправке в «Чат разработчиков»", devchat)
    db.event(user_id, "rights_changed", "Боту не хватает прав в «Кофейня на Арбате»: can_post_messages", coffee)


def create_demo_user() -> int:
    n = db.one("SELECT COALESCE(MIN(telegram_id), 0) AS m FROM users WHERE telegram_id < 0")["m"]
    uid = db.insert("users", telegram_id=min(n, 0) - 1, first_name="Демо-пользователь", username="demo", language="ru",
                    is_demo=1, plan="pro", created_at=db.now_iso(), last_seen_at=db.now_iso())
    with db.tx():
        seed_demo(uid)
    return uid
