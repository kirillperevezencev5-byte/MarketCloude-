"""A fake Telegram Bot API server (stdlib) for integration tests. Supports scripted failures."""
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BOT_ID = 777
FULL_ADMIN = {"status": "administrator", "can_post_messages": True, "can_edit_messages": True,
              "can_delete_messages": True, "can_restrict_members": True, "can_pin_messages": True}


class FakeTelegram:
    def __init__(self):
        self.lock = threading.Lock()
        self.updates: list[dict] = []
        self._next_update = 1
        self.sent: list[dict] = []              # successful sendMessage / sendPhoto
        self.calls: list[tuple[str, dict]] = []
        self.send_script: list[tuple] = []      # ("error", code, desc, params) | ("drop",)
        self.members: dict[tuple[int, int], dict] = {}   # (chat_id, user_id) -> ChatMember
        self.member_count = 1234
        self._msg_id = 100
        self.server = None

    # ---- test helpers
    def push(self, **update) -> int:
        with self.lock:
            uid = self._next_update
            self._next_update += 1
            self.updates.append({"update_id": uid, **update})
            return uid

    def script_send(self, *steps):
        with self.lock:
            self.send_script.extend(steps)

    def set_member(self, chat_id, user_id, member):
        self.members[(chat_id, user_id)] = member

    def sent_texts(self):
        with self.lock:
            return [m["text"] for m in self.sent]

    # ---- server
    def start(self) -> str:
        fake = self

        class H(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *a):
                pass

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")
                method = self.path.rsplit("/", 1)[-1]
                with fake.lock:
                    fake.calls.append((method, body))
                try:
                    result = fake.handle(method, body, self)
                except _Drop:
                    self.close_connection = True
                    self.connection.close()
                    return
                self._reply(result)

            def _reply(self, payload):
                data = json.dumps(payload).encode()
                self.send_response(200 if payload.get("ok") else payload.get("error_code", 400))
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.server.daemon_threads = True
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        return f"http://127.0.0.1:{self.server.server_address[1]}"

    def stop(self):
        if self.server:
            self.server.shutdown()

    def handle(self, method, body, handler):
        ok = lambda r: {"ok": True, "result": r}  # noqa: E731
        if method == "getMe":
            return ok({"id": BOT_ID, "is_bot": True, "username": "FakePilotBot"})
        if method == "deleteWebhook":
            return ok(True)
        if method == "getUpdates":
            offset = body.get("offset", 0)
            deadline = time.time() + min(float(body.get("timeout", 0)), 1.0)
            while True:
                with self.lock:
                    batch = [u for u in self.updates if u["update_id"] >= offset][: body.get("limit", 50)]
                if batch or time.time() >= deadline:
                    return ok(batch)
                time.sleep(0.05)
        if method == "getChatMemberCount":
            return ok(self.member_count)
        if method == "getChatMember":
            m = self.members.get((body["chat_id"], body["user_id"]))
            if m is None:
                m = FULL_ADMIN if body["user_id"] == BOT_ID else {"status": "member"}
            return ok({**m, "user": {"id": body["user_id"]}})
        if method in ("sendMessage", "sendPhoto"):
            with self.lock:
                step = self.send_script.pop(0) if self.send_script else None
            if step and step[0] == "drop":
                raise _Drop()
            if step and step[0] == "error":
                _, code, desc, params = (step + ({},))[:4]
                return {"ok": False, "error_code": code, "description": desc, "parameters": params}
            with self.lock:
                self._msg_id += 1
                text = body.get("text") or body.get("caption") or ""
                self.sent.append({"chat_id": body["chat_id"], "text": text, "method": method, "message_id": self._msg_id,
                                  "reply_markup": body.get("reply_markup")})
                return ok({"message_id": self._msg_id})
        return ok(True)


class _Drop(Exception):
    pass
