"""Integration tests: the real app (HTTP server + scheduler + bot polling) against a fake Telegram server.

Run:  python3 -m unittest discover -s tests -v
"""
import hashlib
import hmac
import http.cookiejar
import json
import os
import socket
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from tests.fake_telegram import BOT_ID, FakeTelegram

FAKE = FakeTelegram()
TG_URL = FAKE.start()


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


PORT = _free_port()
TMP = tempfile.mkdtemp(prefix="mp_test_")
os.environ.update({
    "MP_NO_DOTENV": "1", "DB_PATH": os.path.join(TMP, "test.db"), "PORT": str(PORT), "HOST": "127.0.0.1",
    "BOT_TOKEN": "1:TESTTOKEN", "TG_API_BASE": TG_URL, "DEMO_MODE": "1", "SNAPSHOT_INTERVAL_MIN": "360",
    "PUBLIC_URL": "https://mp.example.test",
})

from marketpilot import api, bot, db, scheduler, security, server, telegram  # noqa: E402,F401
from marketpilot.config import cfg  # noqa: E402

BASE = f"http://127.0.0.1:{PORT}"
_threads = {}
_stop = {}


def start_scheduler():
    _stop["sched"] = threading.Event()
    _threads["sched"] = threading.Thread(target=scheduler.run_forever, args=(_stop["sched"],), daemon=True)
    _threads["sched"].start()


def stop_scheduler():
    _stop["sched"].set()
    _threads["sched"].join(5)


def setUpModule():
    db.init()
    _stop["bot"] = threading.Event()
    _threads["bot"] = threading.Thread(target=bot.poll_forever, args=(_stop["bot"],), daemon=True)
    _threads["bot"].start()
    start_scheduler()
    srv = server.make_server()
    _threads["http"] = server.serve_in_thread(srv)
    _stop["srv"] = srv
    wait_for(lambda: telegram.state["connected"], 10, "bot did not connect to the fake Telegram")


def tearDownModule():
    _stop["bot"].set()
    _stop["sched"].set()
    _stop["srv"].shutdown()
    FAKE.stop()


def wait_for(cond, timeout=10, msg="timeout"):
    end = time.time() + timeout
    while time.time() < end:
        v = cond()
        if v:
            return v
        time.sleep(0.1)
    raise AssertionError(msg)


class Client:
    def __init__(self):
        self.jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))

    def call(self, method, path, body=None, headers=None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(BASE + "/api/v1" + path, data=data, method=method,
                                     headers={"Content-Type": "application/json", **(headers or {})})
        try:
            with self.opener.open(req, timeout=15) as r:
                return r.status, json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read() or b"{}")

    def get(self, p): return self.call("GET", p)
    def post(self, p, b=None): return self.call("POST", p, b if b is not None else {})
    def put(self, p, b): return self.call("PUT", p, b)
    def delete(self, p): return self.call("DELETE", p)


_uid_counter = [5000]


def new_tg_user():
    _uid_counter[0] += 1
    return {"id": _uid_counter[0], "first_name": f"User{_uid_counter[0]}", "language_code": "ru"}


def login_via_bot(client, tg_user):
    st, r = client.post("/auth/web/start")
    assert st == 200, r
    token = r["token"]
    FAKE.push(message={"message_id": 1, "from": tg_user, "chat": {"id": tg_user["id"], "type": "private"},
                       "text": f"/start login_{token}"})

    def confirmed():
        s, p = client.post("/auth/web/poll", {"token": token})
        return p if p.get("status") == "confirmed" else None

    return wait_for(confirmed, 10, "web login was not confirmed")


_chat = [-1001000]


def connect_channel(client, tg_user, title="Test channel", ctype="channel"):
    _chat[0] -= 1
    chat = {"id": _chat[0], "type": ctype, "title": title}
    st, r = client.post("/resources/link-code")
    assert st == 200 and r["live"], r
    msg_key = "channel_post" if ctype == "channel" else "message"
    payload = {"message_id": 2, "chat": chat, "text": f"/connect {r['code']}"}
    if ctype != "channel":
        payload["from"] = tg_user
        FAKE.set_member(chat["id"], tg_user["id"], {"status": "creator"})
    FAKE.push(**{msg_key: payload})
    res = wait_for(lambda: next((x for x in client.get("/resources")[1]["items"] if x["title"] == title and not x["is_demo"]), None), 10, "resource was not linked")
    # the bot also answers in the chat via sendMessage; wait for it so it cannot consume a scripted failure meant for a test
    wait_for(lambda: any(m["chat_id"] == chat["id"] for m in list(FAKE.sent)), 10, "bot confirmation was not sent")
    return chat, res


def target_of(client, post_id):
    return client.get(f"/posts/{post_id}")[1]["targets"][0]


def make_user_with_channel(title="Test channel"):
    c, u = Client(), new_tg_user()
    login_via_bot(c, u)
    chat, res = connect_channel(c, u, title)
    return c, u, chat, res


# =============================================================================================
class AuthTests(unittest.TestCase):
    def test_status_reports_connected_bot(self):
        st, r = Client().get("/status")
        self.assertEqual(st, 200)
        self.assertTrue(r["telegram"]["connected"])
        self.assertEqual(r["telegram"]["username"], "FakePilotBot")

    def test_protected_routes_require_auth(self):
        c = Client()
        for method, pattern, fn, public in server.ROUTES:
            if public:
                continue
            path = pattern.pattern.strip("^$").replace("(?P<id>\\d+)", "1")
            st, _ = c.call(method, path[len("/api/v1"):], {} if method in ("POST", "PUT") else None)
            self.assertEqual(st, 401, f"{method} {path} must require auth")

    def test_web_login_via_bot_and_session(self):
        c, u = Client(), new_tg_user()
        r = login_via_bot(c, u)
        self.assertEqual(r["user"]["first_name"], u["first_name"])
        st, me = c.get("/me")
        self.assertEqual(st, 200)
        self.assertFalse(me["is_demo"])
        # the one-time token cannot be reused
        st, r2 = Client().post("/auth/web/poll", {"token": "garbage"})
        self.assertEqual(r2["status"], "expired")

    def test_login_token_is_one_time(self):
        c, u = Client(), new_tg_user()
        st, r = c.post("/auth/web/start")
        FAKE.push(message={"message_id": 1, "from": u, "chat": {"id": u["id"], "type": "private"}, "text": f"/start login_{r['token']}"})
        wait_for(lambda: c.post("/auth/web/poll", {"token": r["token"]})[1]["status"] == "confirmed", 10)
        self.assertEqual(Client().post("/auth/web/poll", {"token": r["token"]})[1]["status"], "expired")

    def _init_data(self, user, age=0, token="1:TESTTOKEN", tamper=False):
        f = {"user": json.dumps(user, separators=(",", ":")), "auth_date": str(int(time.time()) - age), "query_id": "AAH"}
        dcs = "\n".join(f"{k}={v}" for k, v in sorted(f.items()))
        secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
        f["hash"] = hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest()
        if tamper:
            f["user"] = f["user"].replace(str(user["id"]), "1")
        return urllib.parse.urlencode(f)

    def test_miniapp_init_data(self):
        u = new_tg_user()
        st, r = Client().post("/auth/miniapp", {"init_data": self._init_data(u)})
        self.assertEqual(st, 200, r)
        for bad in (self._init_data(u, tamper=True), self._init_data(u, age=10 * 86400), self._init_data(u, token="9:OTHER"), "garbage"):
            st, r = Client().post("/auth/miniapp", {"init_data": bad})
            self.assertEqual(st, 401, r)

    def test_cross_origin_post_rejected(self):
        st, r = Client().call("POST", "/auth/demo", {}, headers={"Origin": "https://evil.example"})
        self.assertEqual(st, 403)


class ResourceAndPublishingTests(unittest.TestCase):
    def test_connect_channel_checks_rights(self):
        c, u, chat, res = make_user_with_channel("Rights channel")
        self.assertEqual(res["status"], "active")
        self.assertIn("publish", res["capabilities"])
        self.assertEqual(res["members"], FAKE.member_count)

    def test_connect_without_post_right_gives_missing_rights(self):
        c, u = Client(), new_tg_user()
        login_via_bot(c, u)
        _chat[0] -= 1
        chat = {"id": _chat[0], "type": "channel", "title": "No-post channel"}
        FAKE.set_member(chat["id"], BOT_ID, {"status": "administrator", "can_post_messages": False})
        code = c.post("/resources/link-code")[1]["code"]
        FAKE.push(channel_post={"message_id": 2, "chat": chat, "text": f"/connect {code}"})
        res = wait_for(lambda: next((x for x in c.get("/resources")[1]["items"] if x["title"] == "No-post channel"), None), 10)
        wait_for(lambda: any(m["chat_id"] == chat["id"] for m in list(FAKE.sent)), 10)
        self.assertEqual(res["status"], "missing_rights")
        self.assertIn("can_post_messages", res["missing_rights"])
        st, r = c.post("/posts", {"text": "x", "resource_ids": [res["id"]], "mode": "now"})
        self.assertEqual(st, 422)
        self.assertEqual(r["error"], "no_rights")
        st, r = c.post("/posts", {"text": "x", "resource_ids": [res["id"]], "mode": "draft"})
        self.assertEqual(st, 201)  # drafts are allowed

    def test_publish_now_reaches_telegram_once(self):
        c, u, chat, res = make_user_with_channel("Publish channel")
        text = f"hello {time.time()}"
        st, p = c.post("/posts", {"text": text, "resource_ids": [res["id"]], "mode": "now"})
        self.assertEqual(st, 201, p)
        t = wait_for(lambda: (x := target_of(c, p["id"]))["status"] == "published" and x, 10, "not published")
        self.assertIsNotNone(t["message_id"])
        time.sleep(2.5)  # give the scheduler time to (wrongly) send again
        self.assertEqual(FAKE.sent_texts().count(text), 1)

    def test_scheduled_post_waits_for_its_time(self):
        c, u, chat, res = make_user_with_channel("Scheduled channel")
        when = (datetime.now(timezone.utc) + timedelta(seconds=3)).isoformat()
        text = f"later {time.time()}"
        st, p = c.post("/posts", {"text": text, "resource_ids": [res["id"]], "mode": "schedule", "scheduled_at": when})
        self.assertEqual(st, 201, p)
        time.sleep(1)
        self.assertEqual(target_of(c, p["id"])["status"], "scheduled")
        self.assertNotIn(text, FAKE.sent_texts())
        wait_for(lambda: target_of(c, p["id"])["status"] == "published", 10, "did not publish at the scheduled time")

    def test_cancel_scheduled(self):
        c, u, chat, res = make_user_with_channel("Cancel channel")
        when = (datetime.now(timezone.utc) + timedelta(seconds=2)).isoformat()
        text = f"cancel me {time.time()}"
        p = c.post("/posts", {"text": text, "resource_ids": [res["id"]], "mode": "schedule", "scheduled_at": when})[1]
        tid = p["targets"][0]["id"]
        self.assertEqual(c.post(f"/post-targets/{tid}/cancel")[0], 200)
        time.sleep(3.5)
        self.assertEqual(target_of(c, p["id"])["status"], "cancelled")
        self.assertNotIn(text, FAKE.sent_texts())

    def test_rate_limit_429_is_retried_without_duplicates(self):
        c, u, chat, res = make_user_with_channel("429 channel")
        text = f"429 {time.time()}"
        FAKE.script_send(("error", 429, "Too Many Requests: retry after 1", {"retry_after": 1}))
        p = c.post("/posts", {"text": text, "resource_ids": [res["id"]], "mode": "now"})[1]
        wait_for(lambda: target_of(c, p["id"])["status"] == "published", 15, "429 was not retried")
        self.assertEqual(FAKE.sent_texts().count(text), 1)

    def test_permanent_error_fails_then_manual_retry_works(self):
        c, u, chat, res = make_user_with_channel("400 channel")
        text = f"400 {time.time()}"
        FAKE.script_send(("error", 400, "Bad Request: can't parse entities", {}))
        p = c.post("/posts", {"text": text, "resource_ids": [res["id"]], "mode": "now"})[1]
        t = wait_for(lambda: (x := target_of(c, p["id"]))["status"] == "failed" and x, 10)
        self.assertIn("can't parse entities", t["error"])
        time.sleep(2)
        self.assertNotIn(text, FAKE.sent_texts())  # no automatic retry for permanent errors
        self.assertEqual(c.post(f"/post-targets/{t['id']}/retry")[0], 200)
        wait_for(lambda: target_of(c, p["id"])["status"] == "published", 10)
        self.assertEqual(FAKE.sent_texts().count(text), 1)

    def test_ambiguous_network_failure_becomes_unknown_never_auto_retried(self):
        c, u, chat, res = make_user_with_channel("Unknown channel")
        text = f"drop {time.time()}"
        FAKE.script_send(("drop",))
        p = c.post("/posts", {"text": text, "resource_ids": [res["id"]], "mode": "now"})[1]
        t = wait_for(lambda: (x := target_of(c, p["id"]))["status"] == "unknown" and x, 10, "connection drop must become 'unknown'")
        time.sleep(2.5)
        self.assertEqual(target_of(c, p["id"])["status"], "unknown")
        self.assertNotIn(text, FAKE.sent_texts())
        self.assertEqual(c.post(f"/post-targets/{t['id']}/retry")[0], 200)  # explicit user decision
        wait_for(lambda: target_of(c, p["id"])["status"] == "published", 10)

    def test_forbidden_403_marks_resource_missing_rights(self):
        c, u, chat, res = make_user_with_channel("403 channel")
        FAKE.script_send(("error", 403, "Forbidden: bot is not a member of the channel chat", {}))
        p = c.post("/posts", {"text": "403", "resource_ids": [res["id"]], "mode": "now"})[1]
        wait_for(lambda: target_of(c, p["id"])["status"] == "failed", 10)
        self.assertEqual(c.get(f"/resources/{res['id']}")[1]["status"], "missing_rights")

    def test_bot_rights_change_and_removal(self):
        c, u, chat, res = make_user_with_channel("Rights change channel")
        FAKE.push(my_chat_member={"chat": chat, "from": u, "old_chat_member": {"status": "administrator"},
                                  "new_chat_member": {"status": "administrator", "can_post_messages": False, "user": {"id": BOT_ID}}})
        wait_for(lambda: c.get(f"/resources/{res['id']}")[1]["status"] == "missing_rights", 10)
        # restore, schedule a post, then remove the bot: the future post must be cancelled
        FAKE.push(my_chat_member={"chat": chat, "from": u, "old_chat_member": {"status": "administrator"},
                                  "new_chat_member": {"status": "administrator", "can_post_messages": True, "user": {"id": BOT_ID}}})
        wait_for(lambda: c.get(f"/resources/{res['id']}")[1]["status"] == "active", 10)
        when = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
        p = c.post("/posts", {"text": "future", "resource_ids": [res["id"]], "mode": "schedule", "scheduled_at": when})[1]
        FAKE.push(my_chat_member={"chat": chat, "from": u, "old_chat_member": {"status": "administrator"},
                                  "new_chat_member": {"status": "kicked", "user": {"id": BOT_ID}}})
        wait_for(lambda: c.get(f"/resources/{res['id']}")[1]["status"] == "disconnected", 10)
        self.assertEqual(target_of(c, p["id"])["status"], "cancelled")

    def test_group_counters_from_events(self):
        c, u = Client(), new_tg_user()
        login_via_bot(c, u)
        chat, res = connect_channel(c, u, "Counter group", "supergroup")
        for _ in range(3):
            FAKE.push(message={"message_id": 9, "from": {"id": 42, "first_name": "m"}, "chat": chat, "text": "private text must not be stored"})
        FAKE.push(chat_member={"chat": chat, "old_chat_member": {"status": "left"}, "new_chat_member": {"status": "member"}})
        FAKE.push(chat_member={"chat": chat, "old_chat_member": {"status": "member"}, "new_chat_member": {"status": "left"}})
        day = db.now().strftime("%Y-%m-%d")

        def stats():
            r = db.one("SELECT * FROM group_stats WHERE resource_id=? AND day=?", res["id"], day)
            return r if r and r["messages"] == 3 and r["joins"] == 1 and r["leaves"] == 1 else None

        wait_for(stats, 10, "group counters are wrong")
        a = c.get("/analytics?days=7")[1]
        self.assertIsNotNone(a["group_activity"])

    def test_validation(self):
        c, u, chat, res = make_user_with_channel("Validation channel")
        ok = {"resource_ids": [res["id"]], "mode": "draft"}
        self.assertEqual(c.post("/posts", {**ok, "text": "x" * 5000})[1]["error"], "too_long")
        self.assertEqual(c.post("/posts", {**ok, "text": "<b>open"})[1]["error"], "bad_format")
        self.assertEqual(c.post("/posts", {**ok, "text": "<script>x</script>"})[1]["error"], "bad_format")
        self.assertEqual(c.post("/posts", {**ok, "text": ""})[0], 422)
        self.assertEqual(c.post("/posts", {"text": "x", "resource_ids": [], "mode": "draft"})[0], 422)
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        self.assertEqual(c.post("/posts", {**ok, "text": "x", "mode": "schedule", "scheduled_at": past})[1]["error"], "past")
        self.assertEqual(c.post("/posts", {**ok, "text": "x", "mode": "schedule", "scheduled_at": "2030-01-01T10:00:00"})[0], 422)  # no tz
        self.assertEqual(c.post("/posts", {**ok, "text": "x", "image_url": "javascript:alert(1)"})[0], 422)
        self.assertEqual(c.post("/posts", {**ok, "text": "x" * 1100, "image_url": "https://example.com/a.jpg"})[1]["error"], "too_long")

    def test_edit_duplicate_delete(self):
        c, u, chat, res = make_user_with_channel("Edit channel")
        p = c.post("/posts", {"text": "v1", "resource_ids": [res["id"]], "mode": "draft"})[1]
        st, p2 = c.put(f"/posts/{p['id']}", {"text": "v2", "resource_ids": [res["id"]], "mode": "draft"})
        self.assertEqual((st, p2["text"]), (200, "v2"))
        st, dup = c.post(f"/posts/{p['id']}/duplicate")
        self.assertEqual(st, 201)
        self.assertEqual(dup["targets"][0]["status"], "draft")
        self.assertEqual(c.delete(f"/posts/{dup['id']}")[0], 200)
        # published posts are locked for editing
        pub = c.post("/posts", {"text": f"pub {time.time()}", "resource_ids": [res["id"]], "mode": "now"})[1]
        wait_for(lambda: target_of(c, pub["id"])["status"] == "published", 10)
        st, r = c.put(f"/posts/{pub['id']}", {"text": "edit", "resource_ids": [res["id"]], "mode": "draft"})
        self.assertEqual((st, r["error"]), (409, "locked"))


class TenantIsolationTests(unittest.TestCase):
    def test_users_cannot_see_or_touch_each_others_data(self):
        a, ua, chat_a, res_a = make_user_with_channel("A channel")
        b, ub, chat_b, res_b = make_user_with_channel("B channel")
        pa = a.post("/posts", {"text": "secret A", "resource_ids": [res_a["id"]], "mode": "draft"})[1]
        tid = pa["targets"][0]["id"]
        self.assertNotIn(res_a["id"], [x["id"] for x in b.get("/resources")[1]["items"]])
        self.assertEqual(b.get(f"/resources/{res_a['id']}")[0], 404)
        self.assertEqual(b.get(f"/posts/{pa['id']}")[0], 404)
        self.assertEqual(b.put(f"/posts/{pa['id']}", {"text": "x", "resource_ids": [res_b["id"]], "mode": "draft"})[0], 404)
        self.assertEqual(b.delete(f"/posts/{pa['id']}")[0], 404)
        self.assertEqual(b.post(f"/post-targets/{tid}/publish-now")[0], 404)
        self.assertEqual(b.post(f"/post-targets/{tid}/cancel")[0], 404)
        self.assertEqual(b.delete(f"/resources/{res_a['id']}")[0], 404)
        self.assertEqual(b.post(f"/resources/{res_a['id']}/check")[0], 404)
        # cannot publish own post into someone else's resource
        self.assertEqual(b.post("/posts", {"text": "x", "resource_ids": [res_a["id"]], "mode": "draft"})[0], 404)
        self.assertNotIn("secret A", json.dumps(b.get("/posts")[1]))
        self.assertNotIn("secret A", json.dumps(b.get("/dashboard")[1]))

    def test_link_code_cannot_be_reused(self):
        c, u = Client(), new_tg_user()
        login_via_bot(c, u)
        chat, res = connect_channel(c, u, "Code channel")
        code = db.one("SELECT code FROM link_codes WHERE user_id=? ORDER BY rowid DESC", db.one("SELECT id FROM users WHERE telegram_id=?", u["id"])["id"])["code"]
        other = Client()
        login_via_bot(other, new_tg_user())
        _chat[0] -= 1
        FAKE.push(channel_post={"message_id": 3, "chat": {"id": _chat[0], "type": "channel", "title": "Hijack"}, "text": f"/connect {code}"})
        time.sleep(1.5)
        self.assertFalse([x for x in other.get("/resources")[1]["items"] if x["title"] == "Hijack"])


class DemoModeTests(unittest.TestCase):
    def test_demo_user_has_data_and_publishes_without_telegram(self):
        c = Client()
        st, r = c.post("/auth/demo")
        self.assertEqual(st, 200)
        self.assertTrue(r["user"]["is_demo"])
        res = c.get("/resources")[1]["items"]
        self.assertGreaterEqual(len(res), 4)
        self.assertTrue(all(x["is_demo"] for x in res))
        dash = c.get("/dashboard")[1]
        self.assertGreater(dash["kpis"]["members"]["value"], 0)
        self.assertEqual(len(dash["labels"]), 30)
        before = len(FAKE.sent)
        target = next(x for x in res if x["status"] == "active")
        st, p = c.post("/posts", {"text": "demo post", "resource_ids": [target["id"]], "mode": "now"})
        self.assertEqual(st, 201)
        wait_for(lambda: target_of(c, p["id"])["status"] == "published", 10)
        self.assertEqual(len(FAKE.sent), before, "demo publishing must not reach Telegram")
        a = c.get("/analytics?days=30")[1]
        self.assertTrue(a["table"] and a["limitations"])
        self.assertFalse(c.get("/dashboard")[1]["views_available"])

    def test_calendar_templates_settings_and_reset(self):
        c = Client()
        c.post("/auth/demo")
        now = datetime.now(timezone.utc)
        st, r = c.get(f"/targets?from={urllib.parse.quote((now - timedelta(days=40)).isoformat())}&to={urllib.parse.quote((now + timedelta(days=40)).isoformat())}")
        self.assertEqual(st, 200)
        self.assertGreater(len(r["items"]), 5)
        self.assertEqual(c.post("/templates", {"name": "T", "text": "<b>x</b>"})[0], 201)
        self.assertEqual(c.post("/templates", {"name": "T", "text": "<b>x"})[0], 422)
        self.assertGreaterEqual(len(c.get("/templates")[1]["items"]), 3)
        st, me = c.put("/me", {"language": "en", "timezone": "Asia/Tokyo", "notify": False, "first_name": "Neo"})
        self.assertEqual((st, me["language"], me["timezone"]), (200, "en", "Asia/Tokyo"))
        self.assertEqual(c.put("/me", {"timezone": "Mars/Base"})[0], 422)
        self.assertEqual(c.post("/me/reset-demo")[0], 200)
        self.assertGreaterEqual(len(c.get("/resources")[1]["items"]), 4)

    def test_demo_resource_rights_simulation_blocks_publishing(self):
        c = Client()
        c.post("/auth/demo")
        res = next(x for x in c.get("/resources")[1]["items"] if x["status"] == "active")
        self.assertEqual(c.post(f"/resources/{res['id']}/simulate-rights")[1]["status"], "missing_rights")
        self.assertEqual(c.post("/posts", {"text": "x", "resource_ids": [res["id"]], "mode": "now"})[1]["error"], "no_rights")
        self.assertEqual(c.post(f"/resources/{res['id']}/simulate-rights")[1]["status"], "active")

    def test_real_account_can_load_and_remove_demo_data(self):
        c, u, chat, res = make_user_with_channel("Real channel")
        self.assertEqual(c.post("/me/demo-data")[0], 200)
        items = c.get("/resources")[1]["items"]
        self.assertTrue(any(x["is_demo"] for x in items) and any(not x["is_demo"] for x in items))
        self.assertEqual(c.delete("/me/demo-data")[0], 200)
        items = c.get("/resources")[1]["items"]
        self.assertEqual([x["title"] for x in items], ["Real channel"])

    def test_account_deletion_removes_everything(self):
        c, u, chat, res = make_user_with_channel("Delete channel")
        c.post("/posts", {"text": "bye", "resource_ids": [res["id"]], "mode": "draft"})
        uid = db.one("SELECT id FROM users WHERE telegram_id=?", u["id"])["id"]
        self.assertEqual(c.delete("/me")[0], 200)
        for table in ("users", "resources", "posts", "post_targets", "sessions"):
            col = "id" if table == "users" else ("user_id")
            self.assertEqual(db.one(f"SELECT COUNT(*) n FROM {table} WHERE {col}=?", uid)["n"], 0, table)
        self.assertEqual(c.get("/me")[0], 401)


class ConcurrencyTests(unittest.TestCase):
    def test_parallel_claims_never_overlap(self):
        stop_scheduler()
        try:
            c = Client()
            c.post("/auth/demo")
            res = next(x for x in c.get("/resources")[1]["items"] if x["status"] == "active")
            ids = []
            for i in range(40):
                p = c.post("/posts", {"text": f"p{i}", "resource_ids": [res["id"]], "mode": "now"})[1]
                ids.append(p["targets"][0]["id"])
            claimed, lock = [], threading.Lock()

            def worker():
                while True:
                    got = scheduler.claim_due()
                    if not got:
                        return
                    with lock:
                        claimed.extend(got)

            ts = [threading.Thread(target=worker) for _ in range(6)]
            [t.start() for t in ts]
            [t.join() for t in ts]
            mine = [x for x in claimed if x in ids]
            self.assertEqual(len(mine), len(set(mine)), "a target was claimed twice")
            self.assertEqual(set(mine), set(ids))
            # simulate a crash mid-send: stuck 'publishing' becomes 'unknown'
            db.run("UPDATE post_targets SET started_at=? WHERE id=?", db.iso(db.now() - timedelta(minutes=10)), ids[0])
            self.assertGreaterEqual(scheduler.recover_stuck(), 1)
            self.assertEqual(db.one("SELECT status FROM post_targets WHERE id=?", ids[0])["status"], "unknown")
        finally:
            start_scheduler()


class MiniAppTests(unittest.TestCase):
    def _login(self):
        u = new_tg_user()
        data = AuthTests._init_data(self, u)
        c = Client()
        st, r = c.post("/auth/miniapp", {"init_data": data})
        self.assertEqual(st, 200, r)
        return u, r

    def test_start_sends_web_app_button(self):
        u = new_tg_user()
        FAKE.push(message={"message_id": 1, "from": u, "chat": {"id": u["id"], "type": "private"}, "text": "/start"})
        m = wait_for(lambda: next((x for x in FAKE.sent if x["chat_id"] == u["id"] and x["reply_markup"]), None), 10, "no welcome")
        btn = m["reply_markup"]["inline_keyboard"][0][0]
        self.assertEqual(btn["web_app"]["url"], "https://mp.example.test/app/")
        self.assertIn("Открыть приложение", btn["text"])

    def test_menu_button_and_commands_configured(self):
        names = [n for n, _ in FAKE.calls]
        self.assertIn("setMyCommands", names)
        self.assertIn("setChatMenuButton", names)
        body = next(b for n, b in FAKE.calls if n == "setChatMenuButton")
        self.assertEqual(body["menu_button"]["web_app"]["url"], "https://mp.example.test/app/")

    def test_bearer_token_and_notifications(self):
        u, r = self._login()
        self.assertTrue(r["token"])
        c = Client()  # no cookie: only the Bearer token
        h = {"Authorization": "Bearer " + r["token"]}
        st, me = c.call("GET", "/me", headers=h)
        self.assertEqual(st, 200)
        self.assertEqual(me["telegram_id"], u["id"])
        self.assertEqual(Client().get("/notifications")[0], 401)
        st, n = c.call("GET", "/notifications", headers=h)
        self.assertEqual((st, n["unread"]), (200, 0))
        c.call("POST", "/me/demo-data", {}, headers=h)
        st, n = c.call("GET", "/notifications", headers=h)
        db.event(me["id"], "published", "тест") if hasattr(db, "event") else None
        st, n = c.call("GET", "/notifications", headers=h)
        self.assertGreaterEqual(n["unread"], 1)
        self.assertEqual(c.call("POST", "/notifications/read", {}, headers=h)[1]["unread"], 0)
        self.assertEqual(c.call("GET", "/notifications", headers=h)[1]["unread"], 0)

    def test_notifications_isolated(self):
        _, a = self._login()
        _, b = self._login()
        ha, hb = {"Authorization": "Bearer " + a["token"]}, {"Authorization": "Bearer " + b["token"]}
        Client().call("POST", "/me/demo-data", {}, headers=ha)
        ids_a = {x["id"] for x in Client().call("GET", "/notifications", headers=ha)[1]["items"]}
        ids_b = {x["id"] for x in Client().call("GET", "/notifications", headers=hb)[1]["items"]}
        self.assertFalse(ids_a & ids_b)

    def test_static_miniapp(self):
        with urllib.request.urlopen(BASE + "/app/", timeout=10) as r:
            body = r.read().decode()
            self.assertEqual(r.status, 200)
            self.assertIn("telegram-web-app.js", body)
            self.assertIn("frame-ancestors", r.headers.get("Content-Security-Policy", ""))
        for p in ("/app/app.js", "/app/tg.js", "/app/app.css"):
            with urllib.request.urlopen(BASE + p, timeout=10) as r:
                self.assertEqual(r.status, 200)
        opener = urllib.request.build_opener(type("NoRedir", (urllib.request.HTTPRedirectHandler,), {"redirect_request": lambda *a, **k: None}))
        try:
            opener.open(BASE + "/app", timeout=10)
            self.fail("expected redirect")
        except urllib.error.HTTPError as e:
            self.assertIn(e.code, (301, 302, 307, 308))
            self.assertTrue(e.headers["Location"].endswith("/app/"))


if __name__ == "__main__":
    unittest.main()
